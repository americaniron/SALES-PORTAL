export type QuoteCartItem = {
  sku: string;
  description: string;
  unit_price: number;
  quantity: number;
};

const KEY = 'ai_portal_quote_cart_v1';

function safeParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function readQuoteCart(): QuoteCartItem[] {
  const parsed = safeParse<unknown>(localStorage.getItem(KEY));
  if (!Array.isArray(parsed)) return [];
  // basic shape validation
  return parsed
    .map((x: any) => ({
      sku: String(x?.sku || '').trim(),
      description: String(x?.description || '').trim(),
      unit_price: Number(x?.unit_price || 0),
      quantity: Math.max(1, Number(x?.quantity || 1)),
    }))
    .filter((x) => x.sku.length > 0);
}

export function writeQuoteCart(items: QuoteCartItem[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
}

export function clearQuoteCart() {
  localStorage.removeItem(KEY);
}

export function addToQuoteCart(item: QuoteCartItem) {
  const cur = readQuoteCart();
  const sku = String(item.sku || '').trim();
  if (!sku) return;

  const idx = cur.findIndex((x) => String(x.sku).trim() === sku);
  if (idx >= 0) {
    cur[idx] = {
      ...cur[idx],
      // keep the most descriptive description
      description: cur[idx].description?.length ? cur[idx].description : item.description,
      unit_price: cur[idx].unit_price || item.unit_price,
      quantity: Math.max(1, Number(cur[idx].quantity || 1) + Math.max(1, Number(item.quantity || 1))),
    };
  } else {
    cur.push({
      sku,
      description: String(item.description || '').trim(),
      unit_price: Number(item.unit_price || 0),
      quantity: Math.max(1, Number(item.quantity || 1)),
    });
  }
  writeQuoteCart(cur);
}

export function getQuoteCartCount(): number {
  return readQuoteCart().reduce((sum, i) => sum + Math.max(1, Number(i.quantity || 1)), 0);
}
