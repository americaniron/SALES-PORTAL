import { GoogleGenAI, Type } from '@google/genai';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { SignJWT, jwtVerify } from 'jose';
import * as bcrypt from 'bcryptjs';

type EventContext<Env, P extends string = string> = {
  request: Request;
  env: Env;
  params: Record<P, string | string[]>;
};

/**
 * Cloudflare Pages Functions API
 * - Uses D1 for storage (no DB secrets in the browser)
 * - JWT auth (Bearer token)
 * - Minimal, production-safe routing under /api/*
 */

interface Env {
  // Cloudflare D1 binding name
  DB: any;

  // Secrets / vars
  JWT_SECRET?: string;
  GEMINI_API_KEY?: string;
  GEMINI_MODEL?: string;

  // Google Workspace (Gmail API) outbound email
  // NOTE: Cloudflare Workers/Pages Functions cannot use SMTP directly (no raw TCP).
  // Use Gmail API with OAuth2.
  GOOGLE_OAUTH_CLIENT_ID?: string;
  GOOGLE_OAUTH_CLIENT_SECRET?: string;
  GOOGLE_OAUTH_REFRESH_TOKEN?: string;
  EMAIL_FROM?: string; // e.g. info@americaniron1.com
  EMAIL_FROM_NAME?: string; // e.g. American Iron LLC

  // Public lead ingest (from americanironus.com forms)
  PUBLIC_INGEST_API_KEY?: string;

  // Facebook Webhook verification token (for /api/facebook/webhook)
  FB_WEBHOOK_VERIFY_TOKEN?: string;

  // Optional inventory integration (your public website / inventory service)
  INVENTORY_API_BASE_URL?: string;
  INVENTORY_API_KEY?: string;
  INVENTORY_PUBLIC_FEED_URL?: string; // e.g. https://americanironus.com/api/inventory.json

  // Optional (for development only)
  ALLOW_EMERGENCY_BYPASS?: string; // "true" to enable admin bypass
}

const json = (data: unknown, init: ResponseInit = {}) => {
  const headers = new Headers(init.headers);
  headers.set('Content-Type', 'application/json');
  headers.set('Cache-Control', 'no-store');
  return new Response(JSON.stringify(data), { ...init, headers });
};

const badRequest = (message: string, details?: unknown) =>
  json({ error: message, details }, { status: 400 });

const unauthorized = (message = 'Unauthorized') => json({ error: message }, { status: 401 });
const forbidden = (message = 'Forbidden') => json({ error: message }, { status: 403 });

const nowIso = () => new Date().toISOString();

function getBearerToken(req: Request): string | null {
  const auth = req.headers.get('Authorization') || '';
  const m = auth.match(/^Bearer\s+(.+)$/i);
  return m?.[1] || null;
}

async function verifyJwt(env: Env, token: string) {
  const secret = new TextEncoder().encode(env.JWT_SECRET || 'change-me-in-cloudflare-env');
  const { payload } = await jwtVerify(token, secret);
  return payload as any;
}

async function signJwt(env: Env, payload: Record<string, unknown>) {
  const secret = new TextEncoder().encode(env.JWT_SECRET || 'change-me-in-cloudflare-env');
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('12h')
    .sign(secret);
}

type Role = 'admin' | 'sales' | 'accounting' | 'customer';

function requireRole(user: any, allowed: Role[]) {
  if (!user?.role) throw new Error('NO_ROLE');
  if (!allowed.includes(user.role)) throw new Error('FORBIDDEN');
}

async function initSchema(env: Env) {
  // Idempotent schema creation. Runs on each request (fast, D1 caches), safe for small apps.
  // If you prefer migrations, keep this but run it only from an admin endpoint.
  await env.DB.exec(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      company_name TEXT NOT NULL,
      contact_name TEXT,
      email TEXT,
      phone TEXT,
      location TEXT,
      billing_address TEXT,
      shipping_address TEXT,
      credit_limit REAL DEFAULT 0,
      status TEXT DEFAULT 'Active',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY,
      customer_id TEXT,
      customer_name TEXT,
      status TEXT DEFAULT 'draft',
      version INTEGER DEFAULT 1,
      tax_rate REAL DEFAULT 0.0825,
      subtotal REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      total_amount REAL DEFAULT 0,
      created_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(customer_id) REFERENCES customers(id),
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS quote_items (
      id TEXT PRIMARY KEY,
      quote_id TEXT NOT NULL,
      sku TEXT,
      description TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      total REAL NOT NULL,
      FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY,
      quote_id TEXT,
      customer_id TEXT,
      customer_name TEXT,
      status TEXT DEFAULT 'draft',
      amount_due REAL DEFAULT 0,
      due_date TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(quote_id) REFERENCES quotes(id),
      FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS ai_suggestions (
      id TEXT PRIMARY KEY,
      customer_id TEXT,
      type TEXT NOT NULL,
      suggestion TEXT NOT NULL,
      confidence REAL DEFAULT 0.5,
      status TEXT DEFAULT 'suggested',
      generated_message TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_items (
      id TEXT PRIMARY KEY,
      sku TEXT UNIQUE,
      title TEXT,
      description TEXT,
      category TEXT,
      price REAL,
      qty INTEGER,
      location TEXT,
      url TEXT,
      image_url TEXT,
      updated_at TEXT NOT NULL
    );


    CREATE TABLE IF NOT EXISTS equipment_items (
      id TEXT PRIMARY KEY,
      equipment_id TEXT UNIQUE,
      category TEXT,
      make TEXT,
      model TEXT,
      year INTEGER,
      meter_value REAL,
      price_usd REAL,
      city TEXT,
      state TEXT,
      image_path TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS parts_items (
      id TEXT PRIMARY KEY,
      part_no TEXT UNIQUE,
      title TEXT,
      details TEXT,
      category TEXT,
      price_usd REAL,
      qty REAL,
      location TEXT,
      image_path TEXT,
      source_pdf_page INTEGER,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS leads (
      id TEXT PRIMARY KEY,
      email TEXT,
      phone TEXT,
      name TEXT,
      company TEXT,
      source TEXT,
      tags TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
    CREATE INDEX IF NOT EXISTS idx_leads_phone ON leads(phone);

    CREATE TABLE IF NOT EXISTS marketing_templates (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      subject TEXT NOT NULL,
      html TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS marketing_campaigns (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      template_id TEXT,
      segment_json TEXT,
      status TEXT NOT NULL DEFAULT 'draft',
      created_at TEXT NOT NULL,
      sent_at TEXT,
      FOREIGN KEY(template_id) REFERENCES marketing_templates(id)
    );

    CREATE TABLE IF NOT EXISTS marketing_queue (
      id TEXT PRIMARY KEY,
      lead_id TEXT,
      to_email TEXT NOT NULL,
      subject TEXT NOT NULL,
      html TEXT NOT NULL,
      send_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      error TEXT,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_mq_send_at ON marketing_queue(send_at);
    CREATE INDEX IF NOT EXISTS idx_mq_status ON marketing_queue(status);

    

    CREATE TABLE IF NOT EXISTS marketing_campaigns_ui (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      subject TEXT NOT NULL,
      body_html TEXT NOT NULL,
      tag_filter TEXT,
      status TEXT NOT NULL DEFAULT 'draft',
      created_at TEXT NOT NULL,
      sent_at TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_mcu_status ON marketing_campaigns_ui(status);
CREATE TABLE IF NOT EXISTS facebook_pages (
      id TEXT PRIMARY KEY,
      page_id TEXT UNIQUE,
      page_name TEXT,
      access_token TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS facebook_events (
      id TEXT PRIMARY KEY,
      page_id TEXT,
      type TEXT,
      sender_id TEXT,
      sender_name TEXT,
      message TEXT,
      created_at TEXT NOT NULL,
      raw_json TEXT
    );
  `);
}

async function getUserFromRequest(env: Env, req: Request) {
  const token = getBearerToken(req);
  if (!token) return null;
  try {
    return await verifyJwt(env, token);
  } catch {
    return null;
  }
}

function safeLowerEmail(email: unknown): string {
  return String(email || '').trim().toLowerCase();
}

function calcQuote(items: Array<{ quantity: number; unit_price: number }>, taxRate: number) {
  const subtotal = items.reduce((s, it) => s + Number(it.quantity || 0) * Number(it.unit_price || 0), 0);
  const tax = subtotal * (Number.isFinite(taxRate) ? taxRate : 0);
  const total = subtotal + tax;
  return {
    subtotal: Number(subtotal.toFixed(2)),
    tax: Number(tax.toFixed(2)),
    total: Number(total.toFixed(2)),
  };
}

// ---------------------------
// Google Workspace email (Gmail API)
// ---------------------------
function base64UrlEncode(data: string) {
  return btoa(data).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function gmailAccessToken(env: Env): Promise<string> {
  if (!env.GOOGLE_OAUTH_CLIENT_ID || !env.GOOGLE_OAUTH_CLIENT_SECRET || !env.GOOGLE_OAUTH_REFRESH_TOKEN) {
    throw new Error('GMAIL_OAUTH_NOT_CONFIGURED');
  }

  const form = new URLSearchParams();
  form.set('client_id', env.GOOGLE_OAUTH_CLIENT_ID);
  form.set('client_secret', env.GOOGLE_OAUTH_CLIENT_SECRET);
  form.set('refresh_token', env.GOOGLE_OAUTH_REFRESH_TOKEN);
  form.set('grant_type', 'refresh_token');

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data?.access_token) {
    throw new Error(`GMAIL_OAUTH_TOKEN_ERROR: ${data?.error || res.status}`);
  }
  return String(data.access_token);
}

function buildMimeEmail(opts: {
  fromEmail: string;
  fromName?: string;
  toEmail: string;
  toName?: string;
  subject: string;
  html: string;
  attachmentName?: string;
  attachmentBytes?: Uint8Array;
  replyTo?: string;
}) {
  const boundary = 'ai_portal_' + crypto.randomUUID().replace(/-/g, '');
  const from = opts.fromName ? `${opts.fromName} <${opts.fromEmail}>` : opts.fromEmail;
  const to = opts.toName ? `${opts.toName} <${opts.toEmail}>` : opts.toEmail;

  const headers = [
    `From: ${from}`,
    `To: ${to}`,
    opts.replyTo ? `Reply-To: ${opts.replyTo}` : '',
    `Subject: ${opts.subject}`,
    'MIME-Version: 1.0',
    opts.attachmentBytes
      ? `Content-Type: multipart/mixed; boundary="${boundary}"`
      : 'Content-Type: text/html; charset="UTF-8"',
  ].filter(Boolean).join('\r\n');

  if (!opts.attachmentBytes) {
    return headers + '\r\n\r\n' + opts.html;
  }

  // Gmail expects standard base64 in the MIME body
  let bin = '';
  const bytes = opts.attachmentBytes;
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  const b64 = btoa(bin);

  const bodyParts = [
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: 7bit',
    '',
    opts.html,
    '',
    `--${boundary}`,
    `Content-Type: application/pdf; name="${opts.attachmentName || 'quote.pdf'}"`,
    'Content-Transfer-Encoding: base64',
    `Content-Disposition: attachment; filename="${opts.attachmentName || 'quote.pdf'}"`,
    '',
    b64,
    '',
    `--${boundary}--`,
    '',
  ].join('\r\n');

  return headers + '\r\n\r\n' + bodyParts;
}

async function gmailSend(env: Env, mime: string) {
  const accessToken = await gmailAccessToken(env);
  const raw = base64UrlEncode(mime);

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`GMAIL_SEND_ERROR: ${data?.error?.message || res.status}`);
  }
  return data;
}

async function upsertInventoryFromFeed(env: Env) {
  const feedUrl = env.INVENTORY_PUBLIC_FEED_URL;
  if (!feedUrl) return { synced: 0, source: null };

  const res = await fetch(feedUrl, { headers: { 'Accept': 'application/json' } });
  if (!res.ok) throw new Error(`Inventory feed fetch failed: ${res.status}`);
  const data = await res.json() as any;
  const items: any[] = Array.isArray(data) ? data : Array.isArray(data.items) ? data.items : [];
  let synced = 0;

  const stmt = env.DB.prepare(`
    INSERT INTO inventory_items (id, sku, title, description, category, price, qty, location, url, image_url, updated_at)
    VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
    ON CONFLICT(sku) DO UPDATE SET
      title=excluded.title,
      description=excluded.description,
      category=excluded.category,
      price=excluded.price,
      qty=excluded.qty,
      location=excluded.location,
      url=excluded.url,
      image_url=excluded.image_url,
      updated_at=excluded.updated_at;
  `);

  const batch: any[] = [];
  for (const it of items) {
    const sku = String(it.sku || it.part_no || it.id || '').trim();
    if (!sku) continue;
    batch.push(
      stmt.bind(
        crypto.randomUUID(),
        sku,
        String(it.title || it.name || ''),
        String(it.description || ''),
        String(it.category || ''),
        it.price == null ? null : Number(it.price),
        it.qty == null ? null : Number(it.qty),
        String(it.location || ''),
        String(it.url || ''),
        String(it.image_url || it.image || ''),
        nowIso(),
      )
    );
  }

  if (batch.length) {
    const resBatch = await env.DB.batch(batch);
    synced = resBatch.length;
  }

  return { synced, source: feedUrl };
}

export const onRequest: any = async (context: EventContext<Env>) => {
  const url = new URL(context.request.url);
  const path = String(context.params?.path || '').replace(/^\/+/, '');
  const method = context.request.method.toUpperCase();

  await initSchema(context.env);

  try {
    // ---------------------------
    // Health
    // ---------------------------
    if (path === '' && method === 'GET') {
      return json({ ok: true, service: 'american-iron-portal-api', time: nowIso() });
    }

    // ---------------------------
    // Auth
    // ---------------------------
    if (path === 'auth/login' && method === 'POST') {
      const body = await context.request.json().catch(() => ({}));
      const email = safeLowerEmail(body.email);
      const password = String(body.password || '');

      if (!email || !password) return badRequest('Email and password are required');

      // Optional emergency bypass (OFF by default)
      if (
        context.env.ALLOW_EMERGENCY_BYPASS === 'true' &&
        email === 'admin@americanironus.com' &&
        password === 'admin123'
      ) {
        const token = await signJwt(context.env, {
          sub: 'admin-bypass',
          id: 'admin-bypass',
          email,
          name: 'Emergency Admin',
          role: 'admin',
        });
        return json({
          token,
          user: { id: 'admin-bypass', email, name: 'Emergency Admin', role: 'admin' },
          warning: 'Emergency bypass is enabled (disable in production).'
        });
      }

      const userRow = await context.env.DB
        .prepare('SELECT id, email, name, role, password_hash FROM users WHERE email = ?1 LIMIT 1')
        .bind(email)
        .first<any>();

      if (!userRow) return unauthorized('Invalid credentials');
      const ok = await bcrypt.compare(password, userRow.password_hash);
      if (!ok) return unauthorized('Invalid credentials');

      const token = await signJwt(context.env, {
        sub: userRow.id,
        id: userRow.id,
        email: userRow.email,
        name: userRow.name,
        role: userRow.role,
      });

      return json({
        token,
        user: { id: userRow.id, email: userRow.email, name: userRow.name, role: userRow.role },
      });
    }

    if (path === 'auth/me' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      return json({ user });
    }

    // ---------------------------
    // Users (Admin)
    // ---------------------------
    if (path === 'users' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin']);
      } catch (e: any) {
        return e.message === 'FORBIDDEN' ? forbidden() : unauthorized();
      }

      const body = await context.request.json().catch(() => ({}));
      const name = String(body.name || '').trim();
      const email = safeLowerEmail(body.email);
      const role = String(body.role || 'sales').trim() as Role;
      const password = String(body.password || '');

      if (!name || !email || !password) return badRequest('name, email, password are required');
      if (!['admin', 'sales', 'accounting', 'customer'].includes(role)) return badRequest('Invalid role');
      if (password.length < 8) return badRequest('Password must be at least 8 characters');

      const password_hash = await bcrypt.hash(password, await bcrypt.genSalt(10));
      const id = crypto.randomUUID();
      const created_at = nowIso();

      try {
        await context.env.DB
          .prepare('INSERT INTO users (id, email, name, role, password_hash, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6)')
          .bind(id, email, name, role, password_hash, created_at)
          .run();
      } catch (e: any) {
        return badRequest('Failed to create user (email may already exist)', e?.message);
      }

      return json({ ok: true, id, email, name, role, created_at }, { status: 201 });
    }

    // ---------------------------
    // Customers
    // ---------------------------
    if (path === 'customers' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales', 'accounting']);
      } catch (e: any) {
        return forbidden();
      }

      const q = url.searchParams.get('q')?.trim() || '';
      const rows = await context.env.DB
        .prepare(
          q
            ? `SELECT id, company_name, contact_name, email, phone, location, credit_limit, status, created_at
               FROM customers
               WHERE company_name LIKE ?1 OR email LIKE ?1 OR phone LIKE ?1
               ORDER BY created_at DESC
               LIMIT 200`
            : `SELECT id, company_name, contact_name, email, phone, location, credit_limit, status, created_at
               FROM customers
               ORDER BY created_at DESC
               LIMIT 200`
        )
        .bind(q ? `%${q}%` : null)
        .all<any>();
      return json({ items: rows.results || [] });
    }

    if (path === 'customers' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }
      const body = await context.request.json().catch(() => ({}));
      const company_name = String(body.company_name || '').trim();
      if (!company_name) return badRequest('company_name is required');

      const id = crypto.randomUUID();
      const created_at = nowIso();

      await context.env.DB
        .prepare(`
          INSERT INTO customers (id, company_name, contact_name, email, phone, location, billing_address, shipping_address, credit_limit, status, created_at)
          VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
        `)
        .bind(
          id,
          company_name,
          body.contact_name ? String(body.contact_name) : null,
          body.email ? safeLowerEmail(body.email) : null,
          body.phone ? String(body.phone) : null,
          body.location ? String(body.location) : null,
          body.billing_address ? String(body.billing_address) : null,
          body.shipping_address ? String(body.shipping_address) : null,
          body.credit_limit == null ? 0 : Number(body.credit_limit),
          body.status ? String(body.status) : 'Active',
          created_at
        )
        .run();
      return json({ ok: true, id, created_at }, { status: 201 });
    }

    // ---------------------------
    // Quotes
    // ---------------------------
    if (path === 'quotes' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }

      const body = await context.request.json().catch(() => ({}));
      const customer_name = String(body.customer || body.customer_name || '').trim();
      const items = Array.isArray(body.items) ? body.items : [];
      const tax_rate = body.tax_rate == null ? 0.0825 : Number(body.tax_rate);
      if (!customer_name) return badRequest('customer is required');
      if (!items.length) return badRequest('items are required');

      const { subtotal, tax, total } = calcQuote(
        items.map((i: any) => ({ quantity: Number(i.quantity || 0), unit_price: Number(i.unit_price || 0) })),
        tax_rate
      );

      const quoteId = crypto.randomUUID();
      const created_at = nowIso();
      const updated_at = created_at;
      const status = String(body.status || 'draft');

      await context.env.DB
        .prepare(`
          INSERT INTO quotes (id, customer_name, status, version, tax_rate, subtotal, tax, total_amount, created_by, created_at, updated_at)
          VALUES (?1, ?2, ?3, 1, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
        `)
        .bind(quoteId, customer_name, status, tax_rate, subtotal, tax, total, user.id || user.sub, created_at, updated_at)
        .run();

      const itemStmt = context.env.DB.prepare(`
        INSERT INTO quote_items (id, quote_id, sku, description, quantity, unit_price, total)
        VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
      `);

      const batch: any[] = items.map((i: any) =>
        itemStmt.bind(
          crypto.randomUUID(),
          quoteId,
          i.sku ? String(i.sku) : null,
          String(i.description || ''),
          Number(i.quantity || 0),
          Number(i.unit_price || 0),
          Number((Number(i.quantity || 0) * Number(i.unit_price || 0)).toFixed(2))
        )
      );
      if (batch.length) await context.env.DB.batch(batch);

      return json({ ok: true, id: quoteId, version: 1, subtotal, tax, total, status, created_at }, { status: 201 });
    }

    // ---------------------------
    // Invoices (basic list)
    // ---------------------------
    if (path === 'invoices' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'accounting', 'sales']);
      } catch {
        return forbidden();
      }

      const q = url.searchParams.get('q')?.trim() || '';
      const rows = await context.env.DB
        .prepare(
          q
            ? `SELECT id, customer_name, created_at, due_date, amount_due, status
               FROM invoices
               WHERE id LIKE ?1 OR customer_name LIKE ?1
               ORDER BY created_at DESC
               LIMIT 200`
            : `SELECT id, customer_name, created_at, due_date, amount_due, status
               FROM invoices
               ORDER BY created_at DESC
               LIMIT 200`
        )
        .bind(q ? `%${q}%` : null)
        .all<any>();
      return json({ items: rows.results || [] });
    }

    // ---------------------------
    // AI: parse quote
    // ---------------------------
    if (path === 'ai/parse-quote' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }

      const { text } = await context.request.json().catch(() => ({ text: '' }));
      const input = String(text || '').slice(0, 6000);
      if (!input.trim()) return badRequest('text is required');

      // If Gemini is configured, use it. Otherwise, do a basic heuristic parse.
      if (context.env.GEMINI_API_KEY) {
        const ai = new GoogleGenAI({ apiKey: context.env.GEMINI_API_KEY });
        const model = context.env.GEMINI_MODEL || 'gemini-2.0-flash';
        const resp = await ai.models.generateContent({
          model,
          contents: `Extract quote line items into JSON. Return customer_name (if present) and items[]. Items need sku, description, quantity, unit_price.\n\nTEXT:\n${input}`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                customer_name: { type: Type.STRING },
                items: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      sku: { type: Type.STRING },
                      description: { type: Type.STRING },
                      quantity: { type: Type.NUMBER },
                      unit_price: { type: Type.NUMBER },
                    },
                  },
                },
              },
            },
          },
        });
        const jsonStr = resp.text?.trim() || '{}';
        return json(JSON.parse(jsonStr));
      }

      // Heuristic fallback: try to parse lines containing money + qty
      const lines = input.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const items: any[] = [];
      for (const line of lines) {
        // crude: "SKU ... Qty ... $Unit"
        const money = line.match(/\$\s*([0-9,]+(?:\.[0-9]{1,2})?)/);
        const qty = line.match(/\bQty\b[:\s]*([0-9]+)/i) || line.match(/\b([0-9]{1,4})\s*(ea|each)\b/i);
        if (money) {
          const unit_price = Number(String(money[1]).replace(/,/g, ''));
          const quantity = qty ? Number(qty[1]) : 1;
          const sku = (line.match(/\b([A-Z0-9]{3,}-[A-Z0-9]{2,}|[0-9]{3}-[0-9]{4})\b/) || [])[1] || '';
          const description = line.replace(/\$\s*[0-9,]+(?:\.[0-9]{1,2})?/g, '').slice(0, 160).trim();
          items.push({ sku, description: description || 'Imported Item', quantity, unit_price });
        }
        if (items.length >= 60) break;
      }
      return json({ customer_name: '', items });
    }

    // ---------------------------
    // AI: suggestions
    // ---------------------------
    if (path === 'ai/suggestions' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }

      const rows = await context.env.DB
        .prepare(`SELECT id, customer_id, type, suggestion, confidence, status, generated_message, created_at FROM ai_suggestions ORDER BY created_at DESC LIMIT 100`)
        .all<any>();
      return json({ items: rows.results || [] });
    }

    if (path === 'ai/suggestions' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }

      // Generate a basic weekly campaign suggestion using Gemini if configured.
      const { prompt } = await context.request.json().catch(() => ({ prompt: '' }));
      const p = String(prompt || '').trim();

      let suggestion = 'Review inactive customers and send a re-engagement offer.';
      let message = 'Hello from American Iron! We have new inventory and special pricing this week. Reply with your machine model and needed part numbers for a fast quote.';
      let confidence = 0.75;

      if (context.env.GEMINI_API_KEY) {
        const ai = new GoogleGenAI({ apiKey: context.env.GEMINI_API_KEY });
        const model = context.env.GEMINI_MODEL || 'gemini-2.0-flash';
        const resp = await ai.models.generateContent({
          model,
          contents: `Create ONE concise sales campaign suggestion for a heavy equipment parts dealer. Provide JSON with fields: suggestion, message, confidence (0-1). Context: ${p || 'weekly campaign'}`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                suggestion: { type: Type.STRING },
                message: { type: Type.STRING },
                confidence: { type: Type.NUMBER },
              },
            },
          },
        });
        const obj = JSON.parse(resp.text?.trim() || '{}');
        suggestion = String(obj.suggestion || suggestion);
        message = String(obj.message || message);
        confidence = Number(obj.confidence ?? confidence);
      }

      const id = crypto.randomUUID();
      await context.env.DB
        .prepare(`INSERT INTO ai_suggestions (id, customer_id, type, suggestion, confidence, status, generated_message, created_at)
                  VALUES (?1, NULL, 'campaign', ?2, ?3, 'suggested', ?4, ?5)`)
        .bind(id, suggestion, confidence, message, nowIso())
        .run();
      return json({ ok: true, id });
    }

    if (path.startsWith('ai/suggestions/') && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales']);
      } catch {
        return forbidden();
      }

      const id = path.split('ai/suggestions/')[1];
      const { action } = await context.request.json().catch(() => ({ action: '' }));
      const nextStatus = action === 'approve' ? 'approved' : action === 'reject' ? 'rejected' : null;
      if (!nextStatus) return badRequest('action must be approve|reject');
      await context.env.DB
        .prepare('UPDATE ai_suggestions SET status=?1 WHERE id=?2')
        .bind(nextStatus, id)
        .run();
      return json({ ok: true });
    }

    // ---------------------------
    // Inventory
    // ---------------------------
    if (path === 'inventory/sync' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin']);
      } catch {
        return forbidden();
      }
      const result = await upsertInventoryFromFeed(context.env);
      return json({ ok: true, ...result });
    }

    if (path === 'inventory/search' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales', 'accounting']);
      } catch {
        return forbidden();
      }
      const q = url.searchParams.get('q')?.trim() || '';
      if (!q) return json({ items: [] });
      const rows = await context.env.DB
        .prepare(`
          SELECT sku, title, description, category, price, qty, location, url, image_url, updated_at
          FROM inventory_items
          WHERE sku LIKE ?1 OR title LIKE ?1 OR description LIKE ?1
          ORDER BY updated_at DESC
          LIMIT 50
        `)
        .bind(`%${q}%`)
        .all<any>();
      return json({ items: rows.results || [] });
    }

    // ---------------------------
    // Parts Catalog (from parts_items)
    // ---------------------------
    if (path === 'parts/search' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales', 'accounting']);
      } catch {
        return forbidden();
      }

      const q = url.searchParams.get('q')?.trim() || '';
      const category = url.searchParams.get('category')?.trim() || '';
      const limit = Math.min(200, Math.max(1, Number(url.searchParams.get('limit') || 50)));
      const offset = Math.max(0, Number(url.searchParams.get('offset') || 0));

      const clauses: string[] = [];
      const params: any[] = [];
      if (q) {
        clauses.push('(part_no LIKE ? OR title LIKE ? OR details LIKE ?)');
        params.push(`%${q}%`, `%${q}%`, `%${q}%`);
      }
      if (category) {
        clauses.push('category = ?');
        params.push(category);
      }
      const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';

      const stmt = context.env.DB.prepare(
        `SELECT part_no, title, details, category, price_usd, qty, location, image_path
         FROM parts_items
         ${where}
         ORDER BY updated_at DESC
         LIMIT ? OFFSET ?`
      );

      const rows = await stmt.bind(...params, limit, offset).all<any>();
      return json({ items: rows.results || [] });
    }

    if (path === 'parts/lookup' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales', 'accounting']);
      } catch {
        return forbidden();
      }
      const partNo = url.searchParams.get('part_no')?.trim() || '';
      if (!partNo) return badRequest('part_no is required');
      const row = await context.env.DB
        .prepare(`SELECT part_no, title, details, category, price_usd, qty, location, image_path FROM parts_items WHERE part_no = ?1 LIMIT 1`)
        .bind(partNo)
        .first<any>();
      return json({ item: row || null });
    }

    // ---------------------------
    // Public lead ingest (Website -> Portal)
    // ---------------------------
    if (path === 'leads/ingest' && method === 'POST') {
      const apiKey = context.request.headers.get('x-api-key') || '';
      if (!context.env.PUBLIC_INGEST_API_KEY || apiKey !== context.env.PUBLIC_INGEST_API_KEY) {
        return unauthorized('Invalid API key');
      }

      const body = await context.request.json().catch(() => ({}));
      const email = body.email ? safeLowerEmail(body.email) : null;
      const phone = body.phone ? String(body.phone).trim() : null;

      if (!email && !phone) return badRequest('email or phone is required');

      const now = nowIso();
      const id = crypto.randomUUID();

      const existing = email
        ? await context.env.DB.prepare('SELECT id FROM leads WHERE email = ?1 LIMIT 1').bind(email).first()
        : phone
          ? await context.env.DB.prepare('SELECT id FROM leads WHERE phone = ?1 LIMIT 1').bind(phone).first()
          : null;

      const leadId = existing?.id || id;

      if (existing?.id) {
        await context.env.DB.prepare(`
          UPDATE leads
          SET phone = COALESCE(?2, phone),
              name = COALESCE(?3, name),
              company = COALESCE(?4, company),
              source = COALESCE(?5, source),
              notes = COALESCE(?6, notes),
              updated_at = ?7
          WHERE id = ?1
        `).bind(
          leadId,
          phone,
          body.name ? String(body.name) : null,
          body.company ? String(body.company) : null,
          body.source ? String(body.source) : 'website',
          body.notes ? String(body.notes) : null,
          now
        ).run();
      } else {
        await context.env.DB.prepare(`
          INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
          VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
        `).bind(
          leadId,
          email,
          phone,
          body.name ? String(body.name) : null,
          body.company ? String(body.company) : null,
          body.source ? String(body.source) : 'website',
          body.tags ? JSON.stringify(body.tags) : null,
          body.notes ? String(body.notes) : null,
          now,
          now
        ).run();
      }

      return json({ ok: true, id: leadId });
    }

    // ---------------------------
    // Leads (Authenticated)
    // ---------------------------
    if (path === 'leads' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales', 'accounting']); } catch { return forbidden(); }

      const q = url.searchParams.get('q')?.trim() || '';
      const rows = await context.env.DB.prepare(
        q
          ? `SELECT id, email, phone, name, company, source, tags, notes, created_at, updated_at
             FROM leads
             WHERE email LIKE ?1 OR phone LIKE ?1 OR name LIKE ?1 OR company LIKE ?1
             ORDER BY updated_at DESC
             LIMIT 500`
          : `SELECT id, email, phone, name, company, source, tags, notes, created_at, updated_at
             FROM leads
             ORDER BY updated_at DESC
             LIMIT 500`
      ).bind(q ? `%${q}%` : null).all();

      return json({ items: rows.results || [] });
    }

    // ---------------------------
    // Marketing: Templates
    // ---------------------------
    if (path === 'marketing/templates' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const rows = await context.env.DB.prepare(
        `SELECT id, name, subject, html, created_at FROM marketing_templates ORDER BY created_at DESC LIMIT 200`
      ).all();
      return json({ items: rows.results || [] });
    }

    if (path === 'marketing/templates' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const name = String(body.name || '').trim();
      const subject = String(body.subject || '').trim();
      const html = String(body.html || '').trim();
      if (!name || !subject || !html) return badRequest('name, subject, html are required');

      const id = crypto.randomUUID();
      const created_at = nowIso();
      await context.env.DB.prepare(
        'INSERT INTO marketing_templates (id, name, subject, html, created_at) VALUES (?1, ?2, ?3, ?4, ?5)'
      ).bind(id, name, subject, html, created_at).run();

      return json({ ok: true, id }, { status: 201 });

    }

    // ---------------------------
    // Marketing: Subscribe (Public endpoint from americanironus.com)
    // ---------------------------
    if (path === 'marketing/subscribe' && method === 'POST') {
      const key = context.request.headers.get('X-Subscribe-Key') || '';
      const expected = (context.env as any).MARKETING_SUBSCRIBE_KEY || (context.env as any).PUBLIC_INGEST_API_KEY || '';
      if (!expected) return badRequest('MARKETING_SUBSCRIBE_KEY (or PUBLIC_INGEST_API_KEY) is not configured');
      if (key !== expected) return forbidden('Invalid subscribe key');

      const body = await context.request.json().catch(() => ({}));
      const email = safeLowerEmail(body.email || '');
      if (!email) return badRequest('email is required');

      const phone = body.phone ? String(body.phone).trim() : null;
      const name = body.name ? String(body.name).trim() : null;
      const company = body.company ? String(body.company).trim() : null;
      const tags = body.tags ? String(body.tags).trim() : 'website,subscribe';
      const source = body.source ? String(body.source).trim() : 'website';
      const now = nowIso();
      const id = crypto.randomUUID();

      await context.env.DB.prepare(
        `INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
         ON CONFLICT(email) DO UPDATE SET
           phone=COALESCE(excluded.phone, leads.phone),
           name=COALESCE(excluded.name, leads.name),
           company=COALESCE(excluded.company, leads.company),
           source=excluded.source,
           tags=CASE
             WHEN leads.tags IS NULL OR leads.tags = '' THEN excluded.tags
             WHEN excluded.tags IS NULL OR excluded.tags = '' THEN leads.tags
             ELSE leads.tags || ',' || excluded.tags
           END,
           updated_at=excluded.updated_at`
      ).bind(id, email, phone, name, company, source, tags, null, now, now).run();

      return json({ ok: true });
    }


    // ---------------------------
    // Marketing: Contacts (Portal Marketing UI)
    // ---------------------------
    if (path === 'marketing/contacts' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const rows = await context.env.DB.prepare(
        `SELECT id, name, company, email, phone, COALESCE(tags,'') as tags, COALESCE(source,'') as source, created_at
         FROM leads
         ORDER BY created_at DESC
         LIMIT 5000`
      ).all<any>();

      return json({ items: (rows.results || []) });
    }

    if (path === 'marketing/contacts' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const id = crypto.randomUUID();
      const now = nowIso();
      const email = body.email ? safeLowerEmail(body.email) : null;
      const phone = body.phone ? String(body.phone).trim() : null;

      await context.env.DB.prepare(
        `INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)`
      ).bind(
        id,
        email,
        phone,
        body.name ? String(body.name) : null,
        body.company ? String(body.company) : null,
        'portal',
        body.tags ? String(body.tags) : '',
        null,
        now,
        now
      ).run();

      return json({ ok: true, id }, { status: 201 });
    }

    if (path === 'marketing/contacts/bulk' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const items = Array.isArray(body.items) ? body.items : [];
      if (!items.length) return badRequest('items are required');

      const stmt = context.env.DB.prepare(
        `INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)`
      );

      const batch: any[] = [];
      const now = nowIso();
      for (const it of items) {
        const email = it.email ? safeLowerEmail(it.email) : null;
        const phone = it.phone ? String(it.phone).trim() : null;
        if (!email && !phone) continue;
        batch.push(stmt.bind(
          crypto.randomUUID(),
          email,
          phone,
          it.name ? String(it.name) : null,
          it.company ? String(it.company) : null,
          it.source ? String(it.source) : 'import',
          it.tags ? String(it.tags) : '',
          null,
          now,
          now
        ));
      }

      if (batch.length) await context.env.DB.batch(batch);
      return json({ ok: true, inserted: batch.length });
    }

    if (path.startsWith('marketing/contacts/') && method === 'DELETE') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const id = decodeURIComponent(path.split('/')[2] || '');
      if (!id) return badRequest('id is required');
      await context.env.DB.prepare('DELETE FROM leads WHERE id = ?1').bind(id).run();
      return json({ ok: true });
    }

    // ---------------------------
    // Marketing: Campaigns (Portal Marketing UI)
    // ---------------------------
    if (path === 'marketing/campaigns' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const rows = await context.env.DB.prepare(
        `SELECT id, name, subject, body_html, tag_filter, status, created_at
         FROM marketing_campaigns_ui
         ORDER BY created_at DESC
         LIMIT 200`
      ).all<any>();

      return json({ items: rows.results || [] });
    }

    if (path === 'marketing/campaigns' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const name = String(body.name || '').trim();
      const subject = String(body.subject || '').trim();
      const body_html = String(body.body_html || '').trim();
      const tag_filter = String(body.tag_filter || '').trim();
      if (!name || !subject || !body_html) return badRequest('name, subject, body_html are required');

      const id = crypto.randomUUID();
      const created_at = nowIso();
      await context.env.DB.prepare(
        `INSERT INTO marketing_campaigns_ui (id, name, subject, body_html, tag_filter, status, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5, 'draft', ?6)`
      ).bind(id, name, subject, body_html, tag_filter, created_at).run();

      return json({ ok: true, id }, { status: 201 });
    }

    if (path.startsWith('marketing/campaigns/') && method === 'DELETE') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const id = decodeURIComponent(path.split('/')[2] || '');
      await context.env.DB.prepare('DELETE FROM marketing_campaigns_ui WHERE id = ?1').bind(id).run();
      return json({ ok: true });
    }

    if (path.endsWith('/send') && path.startsWith('marketing/campaigns/') && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const id = decodeURIComponent(path.split('/')[2] || '');
      const camp = await context.env.DB.prepare(
        `SELECT id, name, subject, body_html, tag_filter FROM marketing_campaigns_ui WHERE id = ?1 LIMIT 1`
      ).bind(id).first<any>();
      if (!camp) return notFound('Campaign not found');

      const tag = String(camp.tag_filter || '').trim();
      const leads = await context.env.DB.prepare(
        tag
          ? `SELECT id, email, name FROM leads WHERE email IS NOT NULL AND tags LIKE ?1 LIMIT 2000`
          : `SELECT id, email, name FROM leads WHERE email IS NOT NULL LIMIT 2000`
      ).bind(tag ? `%${tag}%` : null).all<any>();

      const fromEmail = context.env.EMAIL_FROM || 'info@americaniron1.com';
      const fromName = context.env.EMAIL_FROM_NAME || 'American Iron LLC';

      let sent = 0;
      for (const l of (leads.results || [])) {
        try {
          const html = String(camp.body_html)
            .replace(/\{\{name\}\}/g, String(l.name || ''))
            .replace(/\{\{email\}\}/g, String(l.email || ''));
          const mime = buildMimeEmail({
            fromEmail,
            fromName,
            toEmail: String(l.email),
            toName: l.name ? String(l.name) : undefined,
            subject: String(camp.subject),
            html,
          });
          await gmailSend(context.env, mime);
          sent++;
        } catch {
          // continue
        }
      }

      await context.env.DB.prepare(
        `UPDATE marketing_campaigns_ui SET status='sent' WHERE id = ?1`
      ).bind(id).run();

      return json({ ok: true, attempted: (leads.results || []).length, sent });
    }

    // ---------------------------
    // Marketing: Send Campaign Now (simple)
    // ---------------------------
    if (path === 'marketing/send' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const subject = String(body.subject || '').trim();
      const html = String(body.html || '').trim();
      const tag = body.tag ? String(body.tag).trim() : '';
      if (!subject || !html) return badRequest('subject and html are required');

      const rows = await context.env.DB.prepare(
        tag
          ? `SELECT id, email, name FROM leads WHERE email IS NOT NULL AND tags LIKE ?1 LIMIT 2000`
          : `SELECT id, email, name FROM leads WHERE email IS NOT NULL LIMIT 2000`
      ).bind(tag ? `%${tag}%` : null).all();

      const leads = rows.results || [];
      let sent = 0;
      const fromEmail = context.env.EMAIL_FROM || 'info@americaniron1.com';
      const fromName = context.env.EMAIL_FROM_NAME || 'American Iron LLC';

      for (const l of leads) {
        try {
          const personalized = html.replace(/\{\{name\}\}/g, String(l.name || '')).replace(/\{\{email\}\}/g, String(l.email || ''));
          const mime = buildMimeEmail({
            fromEmail,
            fromName,
            toEmail: String(l.email),
            toName: l.name ? String(l.name) : undefined,
            subject,
            html: personalized,
          });
          await gmailSend(context.env, mime);
          sent++;
        } catch (e: any) {
          await context.env.DB.prepare(
            'INSERT INTO marketing_queue (id, lead_id, to_email, subject, html, send_at, status, error, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)'
          ).bind(
            crypto.randomUUID(),
            String(l.id),
            String(l.email),
            subject,
            html,
            nowIso(),
            'error',
            String(e?.message || e),
            nowIso()
          ).run().catch(() => null);
        }
      }

      return json({ ok: true, attempted: leads.length, sent });
    }

    // ---------------------------
    // Inventory import (Equipment / Parts)
    // ---------------------------
    if (path === 'inventory/equipment/import' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const items = Array.isArray(body.items) ? body.items : [];
      if (!items.length) return badRequest('items are required');

      const stmt = context.env.DB.prepare(`
        INSERT INTO equipment_items (id, equipment_id, category, make, model, year, meter_value, price_usd, city, state, image_path, updated_at)
        VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12)
        ON CONFLICT(equipment_id) DO UPDATE SET
          category=excluded.category,
          make=excluded.make,
          model=excluded.model,
          year=excluded.year,
          meter_value=excluded.meter_value,
          price_usd=excluded.price_usd,
          city=excluded.city,
          state=excluded.state,
          image_path=excluded.image_path,
          updated_at=excluded.updated_at;
      `);

      const batch = [];
      for (const it of items) {
        const equipment_id = String(it.equipment_id || it.id || '').trim();
        if (!equipment_id) continue;
        batch.push(stmt.bind(
          crypto.randomUUID(),
          equipment_id,
          it.category ? String(it.category) : null,
          it.make ? String(it.make) : null,
          it.model ? String(it.model) : null,
          it.year == null ? null : Number(it.year),
          it.meter_value == null ? null : Number(it.meter_value),
          it.price_usd == null ? null : Number(it.price_usd),
          it.city ? String(it.city) : null,
          it.state ? String(it.state) : null,
          it.image_path ? String(it.image_path) : null,
          nowIso()
        ));
      }

      // Cloudflare D1 has practical limits on batch sizes; chunk to keep imports reliable.
      let upserted = 0;
      const chunkSize = 100;
      for (let i = 0; i < batch.length; i += chunkSize) {
        await context.env.DB.batch(batch.slice(i, i + chunkSize));
        upserted += Math.min(chunkSize, batch.length - i);
      }
      return json({ ok: true, upserted });
    }

    if (path === 'inventory/parts/import' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const items = Array.isArray(body.items) ? body.items : [];
      if (!items.length) return badRequest('items are required');

      const stmt = context.env.DB.prepare(`
        INSERT INTO parts_items (id, part_no, title, details, category, price_usd, qty, location, image_path, source_pdf_page, updated_at)
        VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
        ON CONFLICT(part_no) DO UPDATE SET
          title=excluded.title,
          details=excluded.details,
          category=excluded.category,
          price_usd=excluded.price_usd,
          qty=excluded.qty,
          location=excluded.location,
          image_path=excluded.image_path,
          source_pdf_page=excluded.source_pdf_page,
          updated_at=excluded.updated_at;
      `);

      const batch = [];
      for (const it of items) {
        const part_no = String(it.part_no || it.sku || '').trim();
        if (!part_no) continue;
        batch.push(stmt.bind(
          crypto.randomUUID(),
          part_no,
          it.title ? String(it.title) : null,
          it.details ? String(it.details) : null,
          it.category ? String(it.category) : null,
          it.price_usd == null ? null : Number(it.price_usd),
          it.qty == null ? null : Number(it.qty),
          it.location ? String(it.location) : null,
          it.image_path ? String(it.image_path) : null,
          it.source_pdf_page == null ? null : Number(it.source_pdf_page),
          nowIso()
        ));
      }

      // Cloudflare D1 has practical limits on batch sizes; chunk to keep imports reliable.
      let upserted = 0;
      const chunkSize = 100;
      for (let i = 0; i < batch.length; i += chunkSize) {
        await context.env.DB.batch(batch.slice(i, i + chunkSize));
        upserted += Math.min(chunkSize, batch.length - i);
      }
      return json({ ok: true, upserted });
    }

    // ---------------------------
    // Quote Email Send (Google Workspace via Gmail API)
    // ---------------------------
    if (path === 'quotes/send' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales', 'accounting']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const toEmail = safeLowerEmail(body.to_email || body.toEmail);
      const toName = body.to_name ? String(body.to_name) : undefined;
      const customer = String(body.customer || body.customer_name || '');
      const quote = body.quote || {};
      const items = Array.isArray(body.items) ? body.items : [];
      const note = String(body.note || '').trim();

      if (!toEmail) return badRequest('to_email is required');
      if (!items.length) return badRequest('items are required');

      const quoteNo = String(quote.id || 'Q-DRAFT');
      const version = String(quote.version || 1);

      const pdfDoc = await PDFDocument.create();
      const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      const page = pdfDoc.addPage([612, 792]);
      let y = 760;

      page.drawText('AMERICAN IRON LLC', { x: 50, y, size: 18, font: fontBold, color: rgb(0, 0, 0) });
      y -= 18;
      page.drawText('QUOTE', { x: 50, y, size: 12, font: fontBold, color: rgb(0.2, 0.2, 0.2) });
      page.drawText(`#${quoteNo}  v${version}`, { x: 430, y: y, size: 12, font: fontBold });
      y -= 18;
      page.drawText(`Date: ${new Date().toLocaleDateString('en-US')}`, { x: 430, y, size: 10, font: fontRegular });
      page.drawText(`Bill To: ${customer || '—'}`, { x: 50, y, size: 10, font: fontRegular });
      y -= 22;

      page.drawText('SKU', { x: 50, y, size: 10, font: fontBold });
      page.drawText('Description', { x: 120, y, size: 10, font: fontBold });
      page.drawText('Qty', { x: 395, y, size: 10, font: fontBold });
      page.drawText('Unit', { x: 440, y, size: 10, font: fontBold });
      page.drawText('Total', { x: 515, y, size: 10, font: fontBold });
      y -= 10;
      page.drawLine({ start: { x: 50, y }, end: { x: 562, y }, thickness: 1, color: rgb(0.85, 0.85, 0.85) });
      y -= 16;

      const lineHeight = 14;
      let subtotal = 0;
      for (const it of items.slice(0, 40)) {
        const sku = String(it.sku || '');
        const desc = String(it.description || '').slice(0, 70);
        const qty = Number(it.quantity || 0);
        const unit = Number(it.unit_price || 0);
        const total = Number((qty * unit).toFixed(2));
        subtotal += total;

        page.drawText(sku, { x: 50, y, size: 9, font: fontRegular });
        page.drawText(desc, { x: 120, y, size: 9, font: fontRegular });
        page.drawText(String(qty), { x: 402, y, size: 9, font: fontRegular });
        page.drawText(`$${unit.toFixed(2)}`, { x: 435, y, size: 9, font: fontRegular });
        page.drawText(`$${total.toFixed(2)}`, { x: 510, y, size: 9, font: fontRegular });
        y -= lineHeight;
        if (y < 120) break;
      }

      const taxRate = 0.0825;
      const tax = subtotal * taxRate;
      const grand = subtotal + tax;

      y = max(y - 10, 130);
      page.drawLine({ start: { x: 360, y }, end: { x: 562, y }, thickness: 1, color: rgb(0.85, 0.85, 0.85) });
      y -= 16;
      page.drawText('Subtotal', { x: 410, y, size: 10, font: fontBold });
      page.drawText(`$${subtotal.toFixed(2)}`, { x: 510, y, size: 10, font: fontRegular });
      y -= 14;
      page.drawText('Tax (8.25%)', { x: 410, y, size: 10, font: fontBold });
      page.drawText(`$${tax.toFixed(2)}`, { x: 510, y, size: 10, font: fontRegular });
      y -= 14;
      page.drawText('Total', { x: 410, y, size: 11, font: fontBold });
      page.drawText(`$${grand.toFixed(2)}`, { x: 510, y: y, size: 11, font: fontBold });

      const disclaimer =
        'Seller makes no warranty, express or implied, with respect to the goods or services, including any warranty of merchantability or fitness for a particular purpose. The goods being sold are sold on an as-is, as they stand, with all faults basis, and seller disclaims any implied warranties with respect to said goods. All other warranty disclaimers contained herein are additionally applicable.';

      page.drawLine({ start: { x: 50, y: 80 }, end: { x: 562, y: 80 }, thickness: 1, color: rgb(0.9, 0.9, 0.9) });
      page.drawText(disclaimer.slice(0, 180), { x: 50, y: 66, size: 7.5, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });
      page.drawText(disclaimer.slice(180, 360), { x: 50, y: 56, size: 7.5, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });
      page.drawText(`Page 1 of 1`, { x: 520, y: 40, size: 8, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });

      const pdfBytes = await pdfDoc.save();
      const pdfUint8 = new Uint8Array(pdfBytes);

      const subject = body.subject ? String(body.subject) : `American Iron Quote ${quoteNo}`;
      const html = `
        <div style="font-family:Arial,Helvetica,sans-serif; line-height:1.5">
          <h2 style="margin:0 0 8px 0;">American Iron LLC – Quote</h2>
          <p style="margin:0 0 10px 0;">Hello ${toName || ''},</p>
          <p style="margin:0 0 10px 0;">Please find your quote attached as a PDF.</p>
          ${note ? `<p style="margin:0 0 10px 0;"><b>Note:</b> ${note.replace(/</g,'&lt;')}</p>` : ''}
          <p style="margin:0 0 10px 0;">If you have any questions, reply to this email.</p>
          <p style="margin:0;">— American Iron LLC</p>
        </div>
      `.trim();

      const fromEmail = context.env.EMAIL_FROM || 'info@americaniron1.com';
      const fromName = context.env.EMAIL_FROM_NAME || 'American Iron LLC';

      const mime = buildMimeEmail({
        fromEmail,
        fromName,
        toEmail,
        toName,
        subject,
        html,
        attachmentName: `${quoteNo}-v${version}.pdf`,
        attachmentBytes: pdfUint8,
        replyTo: fromEmail,
      });

      await gmailSend(context.env, mime);

      return json({ ok: true, to: toEmail, quote: quoteNo });
    }

    // ---------------------------
    
    // ---------------------------
    // Facebook integration (Authenticated management)
    // ---------------------------
    if (path === 'facebook/pages' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin']); } catch { return forbidden(); }

      const rows = await context.env.DB.prepare(`SELECT id, page_id, page_name, created_at FROM facebook_pages ORDER BY created_at DESC LIMIT 50`).all<any>();
      return json({ items: rows.results || [] });
    }

    if (path === 'facebook/pages' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin']); } catch { return forbidden(); }

      const body = await context.request.json().catch(() => ({}));
      const page_id = String(body.page_id || '').trim();
      const page_name = body.page_name ? String(body.page_name).trim() : null;
      const access_token = body.access_token ? String(body.access_token).trim() : null;
      if (!page_id || !access_token) return badRequest('page_id and access_token are required');

      const id = crypto.randomUUID();
      await context.env.DB.prepare(
        `INSERT INTO facebook_pages (id, page_id, page_name, access_token, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5)
         ON CONFLICT(page_id) DO UPDATE SET page_name=excluded.page_name, access_token=excluded.access_token`
      ).bind(id, page_id, page_name, access_token, nowIso()).run();

      return json({ ok: true });
    }

    if (path === 'facebook/events' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const rows = await context.env.DB.prepare(
        `SELECT id, page_id, type, sender_name, message, created_at FROM facebook_events ORDER BY created_at DESC LIMIT 200`
      ).all<any>();
      return json({ items: rows.results || [] });
    }

    // ---------------------------
    // Facebook: Stats + Manual sync helpers (for UI)
    // Notes:
    // - Comments/Messages do NOT reliably provide email/phone due to privacy.
    // - Lead Ads do provide email/phone if the form collects them.
    // - For messages, the recommended approach is webhooks (already implemented below).
    // ---------------------------
    if (path === 'facebook/stats' && method === 'GET') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin', 'sales']); } catch { return forbidden(); }

      const leads = await context.env.DB.prepare(
        `SELECT COUNT(1) as n FROM leads WHERE source = 'facebook_lead_ads' OR tags LIKE '%facebook%leadads%'
        `
      ).first<any>();
      const comments = await context.env.DB.prepare(
        `SELECT COUNT(1) as n FROM facebook_events WHERE type LIKE '%comment%'
        `
      ).first<any>();
      const messages = await context.env.DB.prepare(
        `SELECT COUNT(1) as n FROM facebook_events WHERE type LIKE '%messaging%' OR type LIKE '%message%'
        `
      ).first<any>();
      return json({
        stats: {
          leads: Number(leads?.n || 0),
          comments: Number(comments?.n || 0),
          messages: Number(messages?.n || 0),
        }
      });
    }

    if (path.startsWith('facebook/sync/') && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try { requireRole(user, ['admin']); } catch { return forbidden(); }

      const kind = path.split('/')[2] || '';
      const pages = await context.env.DB.prepare('SELECT page_id, access_token FROM facebook_pages').all<any>();
      const pageRows = pages.results || [];
      if (!pageRows.length) return badRequest('No Facebook Pages configured. Add a page_id + access_token in Settings first.');

      let imported = 0;

      // Helper: upsert a lead into the portal leads table
      const upsertLead = async (lead: { email?: string; phone?: string; name?: string; company?: string; notes?: string; tags?: string; source?: string }) => {
        const email = safeLowerEmail(lead.email || '');
        const phone = lead.phone ? String(lead.phone).trim() : '';
        if (!email && !phone) return;
        const now = nowIso();
        await context.env.DB.prepare(
          `INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
           VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
           ON CONFLICT(email) DO UPDATE SET
             phone=COALESCE(excluded.phone, leads.phone),
             name=COALESCE(excluded.name, leads.name),
             company=COALESCE(excluded.company, leads.company),
             source=excluded.source,
             tags=CASE
               WHEN leads.tags IS NULL OR leads.tags = '' THEN excluded.tags
               WHEN excluded.tags IS NULL OR excluded.tags = '' THEN leads.tags
               ELSE leads.tags || ',' || excluded.tags
             END,
             notes=CASE
               WHEN excluded.notes IS NULL OR excluded.notes = '' THEN leads.notes
               WHEN leads.notes IS NULL OR leads.notes = '' THEN excluded.notes
               ELSE leads.notes || '\n' || excluded.notes
             END,
             updated_at=excluded.updated_at`
        ).bind(
          crypto.randomUUID(),
          email || null,
          phone || null,
          lead.name ? String(lead.name).trim() : null,
          lead.company ? String(lead.company).trim() : null,
          lead.source || 'facebook',
          lead.tags || 'facebook',
          lead.notes || null,
          now,
          now
        ).run();
        imported++;
      };

      const saveEvent = async (evt: { page_id: string; type: string; sender_id?: string; sender_name?: string; message?: string; raw?: any }) => {
        await context.env.DB.prepare(
          'INSERT INTO facebook_events (id, page_id, type, sender_id, sender_name, message, created_at, raw_json) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)'
        ).bind(
          crypto.randomUUID(),
          evt.page_id,
          evt.type,
          evt.sender_id || '',
          evt.sender_name || '',
          evt.message || '',
          nowIso(),
          JSON.stringify(evt.raw || {})
        ).run().catch(() => null);
      };

      for (const p of pageRows) {
        const pageId = String(p.page_id || '').trim();
        const token = String(p.access_token || '').trim();
        if (!pageId || !token) continue;

        if (kind === 'leads') {
          // Pull recent leads from all leadgen forms attached to the page
          // Requires permissions: leads_retrieval, pages_manage_metadata
          const formsRes = await fetch(`https://graph.facebook.com/v19.0/${pageId}/leadgen_forms?fields=id,name&limit=50&access_token=${encodeURIComponent(token)}`);
          const formsJson: any = formsRes.ok ? await formsRes.json().catch(() => ({})) : {};
          const forms: any[] = Array.isArray(formsJson?.data) ? formsJson.data : [];
          for (const form of forms.slice(0, 50)) {
            const formId = String(form?.id || '').trim();
            if (!formId) continue;
            const leadsRes = await fetch(`https://graph.facebook.com/v19.0/${formId}/leads?fields=created_time,field_data&limit=100&access_token=${encodeURIComponent(token)}`);
            if (!leadsRes.ok) continue;
            const leadsJson: any = await leadsRes.json().catch(() => ({}));
            const leads: any[] = Array.isArray(leadsJson?.data) ? leadsJson.data : [];
            for (const ld of leads) {
              const fields: any[] = Array.isArray(ld?.field_data) ? ld.field_data : [];
              const getField = (key: string) => {
                const row = fields.find(f => String(f?.name || '').toLowerCase() === key);
                const vals = Array.isArray(row?.values) ? row.values : [];
                return vals.length ? String(vals[0]) : '';
              };

              await upsertLead({
                email: getField('email'),
                phone: getField('phone_number') || getField('phone') || '',
                name: getField('full_name') || getField('name') || '',
                company: getField('company_name') || '',
                source: 'facebook_lead_ads',
                tags: 'facebook,leadads',
                notes: `form:${formId}`,
              });
            }
          }
        } else if (kind === 'comments') {
          // Fetch a small sample of recent comments from page feed.
          // Requires: pages_read_engagement
          const feedRes = await fetch(`https://graph.facebook.com/v19.0/${pageId}/feed?fields=id,message,created_time,comments.limit(25){from,message,created_time}&limit=10&access_token=${encodeURIComponent(token)}`);
          if (!feedRes.ok) continue;
          const feedJson: any = await feedRes.json().catch(() => ({}));
          const posts: any[] = Array.isArray(feedJson?.data) ? feedJson.data : [];
          for (const post of posts) {
            const comments: any[] = Array.isArray(post?.comments?.data) ? post.comments.data : [];
            for (const c of comments) {
              const from = c?.from || {};
              await saveEvent({
                page_id: pageId,
                type: 'comment',
                sender_id: String(from?.id || ''),
                sender_name: String(from?.name || ''),
                message: String(c?.message || ''),
                raw: c,
              });
            }
          }
        } else if (kind === 'messages') {
          // Messages are best captured via webhooks (Messenger). There is no safe/portable polling API.
          // We still return ok for the UI.
          continue;
        } else {
          return badRequest('Invalid sync kind. Use leads|comments|messages');
        }
      }

      return json({ ok: true, imported });
    }

// Facebook webhook (basic receiver)
    // ---------------------------
    if (path === 'facebook/webhook' && method === 'GET') {
      const verifyToken = url.searchParams.get('hub.verify_token') || '';
      const challenge = url.searchParams.get('hub.challenge') || '';
      if (!context.env.FB_WEBHOOK_VERIFY_TOKEN) return badRequest('FB_WEBHOOK_VERIFY_TOKEN not configured');
      if (verifyToken !== context.env.FB_WEBHOOK_VERIFY_TOKEN) return forbidden('Invalid verify token');
      return new Response(String(challenge || ''), { status: 200 });
    }

    if (path === 'facebook/webhook' && method === 'POST') {
      const payload = await context.request.json().catch(() => ({}));
      const created_at = nowIso();
      const id = crypto.randomUUID();
      const pageId = String(payload?.entry?.[0]?.id || '');
      await context.env.DB.prepare(
        'INSERT INTO facebook_events (id, page_id, type, sender_id, sender_name, message, created_at, raw_json) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)'
      ).bind(
        id,
        pageId,
        String(payload?.object || 'facebook'),
        String(payload?.entry?.[0]?.messaging?.[0]?.sender?.id || payload?.entry?.[0]?.changes?.[0]?.value?.from?.id || ''),
        String(payload?.entry?.[0]?.changes?.[0]?.value?.from?.name || ''),
        String(payload?.entry?.[0]?.messaging?.[0]?.message?.text || payload?.entry?.[0]?.changes?.[0]?.value?.message || ''),
        created_at,
        JSON.stringify(payload)
      ).run().catch(() => null);

      // Best-effort Lead Ads capture (requires: leadgen webhook + pages_manage_metadata + leads_retrieval)
      // Notes: comments/messages do NOT include email/phone due to privacy; lead ads do.
      try {
        const changes = payload?.entry?.[0]?.changes || [];
        let leadId: string | null = null;
        for (const ch of changes) {
          const v = ch?.value || {};
          if (ch?.field === 'leadgen' || v?.leadgen_id || v?.lead_id) {
            leadId = String(v.leadgen_id || v.lead_id || '').trim() || null;
            break;
          }
        }

        if (leadId && pageId) {
          const tokenRow = await context.env.DB.prepare('SELECT access_token FROM facebook_pages WHERE page_id = ?1 LIMIT 1').bind(pageId).first<any>();
          const accessToken = tokenRow?.access_token ? String(tokenRow.access_token) : '';
          if (accessToken) {
            const url = `https://graph.facebook.com/v19.0/${leadId}?fields=created_time,field_data&access_token=${encodeURIComponent(accessToken)}`;
            const leadRes = await fetch(url);
            if (leadRes.ok) {
              const leadJson: any = await leadRes.json().catch(() => ({}));
              const fields: any[] = Array.isArray(leadJson?.field_data) ? leadJson.field_data : [];
              const getField = (key: string) => {
                const row = fields.find(f => String(f?.name || '').toLowerCase() === key);
                const vals = Array.isArray(row?.values) ? row.values : [];
                return vals.length ? String(vals[0]) : '';
              };

              const email = safeLowerEmail(getField('email'));
              const phone = getField('phone_number') || getField('phone') || '';
              const name = getField('full_name') || getField('name') || '';
              const company = getField('company_name') || '';

              if (email || phone) {
                const now = nowIso();
                const leadDbId = crypto.randomUUID();
                await context.env.DB.prepare(
                  `INSERT INTO leads (id, email, phone, name, company, source, tags, notes, created_at, updated_at)
                   VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
                   ON CONFLICT(email) DO UPDATE SET
                     phone=COALESCE(excluded.phone, leads.phone),
                     name=COALESCE(excluded.name, leads.name),
                     company=COALESCE(excluded.company, leads.company),
                     source=excluded.source,
                     tags=CASE
                       WHEN leads.tags IS NULL OR leads.tags = '' THEN excluded.tags
                       WHEN excluded.tags IS NULL OR excluded.tags = '' THEN leads.tags
                       ELSE leads.tags || ',' || excluded.tags
                     END,
                     updated_at=excluded.updated_at`
                ).bind(
                  leadDbId,
                  email || null,
                  phone ? String(phone).trim() : null,
                  name ? String(name).trim() : null,
                  company ? String(company).trim() : null,
                  'facebook_lead_ads',
                  'facebook,leadads',
                  `lead_id:${leadId}`,
                  now,
                  now
                ).run();
              }
            }
          }
        }
      } catch {
        // swallow
      }

      return json({ ok: true });
    }

    // ---------------------------
    // PDF
    // ---------------------------
    if (path === 'pdf/generate' && method === 'POST') {
      const user = await getUserFromRequest(context.env, context.request);
      if (!user) return unauthorized();
      try {
        requireRole(user, ['admin', 'sales', 'accounting']);
      } catch {
        return forbidden();
      }

      const payload = await context.request.json().catch(() => ({}));
      const quote = payload.quote || {};
      const quoteNo = String(quote.id || 'Q-DRAFT');
      const version = String(quote.version || 1);
      const customer = String(payload.customer || payload.customer_name || '');
      const items = Array.isArray(payload.items) ? payload.items : [];

      const pdfDoc = await PDFDocument.create();
      const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

      const page = pdfDoc.addPage([612, 792]); // US Letter
      let y = 760;

      // Header
      page.drawText('AMERICAN IRON LLC', { x: 50, y, size: 18, font: fontBold, color: rgb(0, 0, 0) });
      y -= 18;
      page.drawText('QUOTE', { x: 50, y, size: 12, font: fontBold, color: rgb(0.2, 0.2, 0.2) });
      page.drawText(`#${quoteNo}  v${version}`, { x: 430, y: y, size: 12, font: fontBold });
      y -= 18;
      page.drawText(`Date: ${new Date().toLocaleDateString('en-US')}`, { x: 430, y, size: 10, font: fontRegular });
      page.drawText(`Bill To: ${customer || '—'}`, { x: 50, y, size: 10, font: fontRegular });
      y -= 22;

      // Table header
      page.drawText('SKU', { x: 50, y, size: 10, font: fontBold });
      page.drawText('Description', { x: 120, y, size: 10, font: fontBold });
      page.drawText('Qty', { x: 395, y, size: 10, font: fontBold });
      page.drawText('Unit', { x: 440, y, size: 10, font: fontBold });
      page.drawText('Total', { x: 515, y, size: 10, font: fontBold });
      y -= 10;
      page.drawLine({ start: { x: 50, y }, end: { x: 562, y }, thickness: 1, color: rgb(0.85, 0.85, 0.85) });
      y -= 16;

      const lineHeight = 14;
      let subtotal = 0;
      for (const it of items.slice(0, 40)) {
        const sku = String(it.sku || '');
        const desc = String(it.description || '').slice(0, 70);
        const qty = Number(it.quantity || 0);
        const unit = Number(it.unit_price || 0);
        const total = Number((qty * unit).toFixed(2));
        subtotal += total;

        page.drawText(sku, { x: 50, y, size: 9, font: fontRegular });
        page.drawText(desc, { x: 120, y, size: 9, font: fontRegular });
        page.drawText(String(qty), { x: 402, y, size: 9, font: fontRegular });
        page.drawText(`$${unit.toFixed(2)}`, { x: 435, y, size: 9, font: fontRegular });
        page.drawText(`$${total.toFixed(2)}`, { x: 510, y, size: 9, font: fontRegular });
        y -= lineHeight;
        if (y < 120) break;
      }

      const taxRate = 0.0825;
      const tax = subtotal * taxRate;
      const grand = subtotal + tax;

      y = Math.max(y - 10, 130);
      page.drawLine({ start: { x: 360, y }, end: { x: 562, y }, thickness: 1, color: rgb(0.85, 0.85, 0.85) });
      y -= 16;
      page.drawText('Subtotal', { x: 410, y, size: 10, font: fontBold });
      page.drawText(`$${subtotal.toFixed(2)}`, { x: 510, y, size: 10, font: fontRegular });
      y -= 14;
      page.drawText('Tax (8.25%)', { x: 410, y, size: 10, font: fontBold });
      page.drawText(`$${tax.toFixed(2)}`, { x: 510, y, size: 10, font: fontRegular });
      y -= 14;
      page.drawText('Total', { x: 410, y, size: 11, font: fontBold });
      page.drawText(`$${grand.toFixed(2)}`, { x: 510, y, size: 11, font: fontBold });

      // Footer disclaimer
      const disclaimer =
        'Seller makes no warranty, express or implied, with respect to the goods or services, including any warranty of merchantability or fitness for a particular purpose. The goods being sold are sold on an as-is, as they stand, with all faults basis, and seller disclaims any implied warranties with respect to said goods. All other warranty disclaimers contained herein are additionally applicable.';

      page.drawLine({ start: { x: 50, y: 80 }, end: { x: 562, y: 80 }, thickness: 1, color: rgb(0.9, 0.9, 0.9) });
      page.drawText(disclaimer.slice(0, 180), { x: 50, y: 66, size: 7.5, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });
      page.drawText(disclaimer.slice(180, 360), { x: 50, y: 56, size: 7.5, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });
      page.drawText(`Page 1 of 1`, { x: 520, y: 40, size: 8, font: fontRegular, color: rgb(0.35, 0.35, 0.35) });

      const pdfBytes = await pdfDoc.save();
      return new Response(pdfBytes, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `inline; filename="${quoteNo}-v${version}.pdf"`,
          'Cache-Control': 'no-store',
        },
      });
    }

    return json({ error: 'Not Found' }, { status: 404 });
  } catch (e: any) {
    // Auth helper throws
    if (e?.message === 'FORBIDDEN') return forbidden();
    if (e?.message === 'NO_ROLE') return unauthorized();
    return json({ error: 'Server Error', details: e?.message || String(e) }, { status: 500 });
  }
};
