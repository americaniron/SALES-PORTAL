import React, { useEffect, useMemo, useState } from 'react';
import { Search, Filter, Download, ArrowUpRight, Loader } from 'lucide-react';

type InvoiceRow = {
  id: string;
  customer_name?: string;
  created_at?: string;
  due_date?: string;
  amount_due?: number;
  status?: string;
};

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'Request failed');
  return data as T;
}

const InvoiceList = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<InvoiceRow[]>([]);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await apiFetch<{ items: InvoiceRow[] }>(`/api/invoices${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ''}`);
      setItems(data.items || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load invoices');
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(), 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const summary = useMemo(() => {
    const out = {
      overdue: 0,
      due30: 0,
      drafts: 0,
      paid: 0,
    };
    const today = new Date();
    const in30 = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    for (const inv of items) {
      const amt = Number(inv.amount_due || 0);
      const status = String(inv.status || 'draft');
      if (status.toLowerCase() === 'paid') {
        out.paid += amt;
        continue;
      }
      if (status.toLowerCase() === 'draft') {
        out.drafts += amt;
        continue;
      }
      const due = inv.due_date ? new Date(inv.due_date) : null;
      if (due && due < today) out.overdue += amt;
      else if (due && due <= in30) out.due30 += amt;
    }
    return out;
  }, [items]);

  const exportCsv = () => {
    const rows = [
      ['invoice_id', 'customer', 'date_issued', 'due_date', 'amount_due', 'status'],
      ...items.map((i) => [
        i.id,
        i.customer_name || '',
        i.created_at || '',
        i.due_date || '',
        String(i.amount_due || 0),
        i.status || '',
      ]),
    ];
    const csv = rows
      .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `american-iron-invoices-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Invoices</h1>
        <div className="flex gap-3">
          <button
            onClick={exportCsv}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium transition-colors"
          >
            <Download size={18} />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => alert('Invoice creation screen coming next. For now, create invoices from a quote in the backend.')}
            className="bg-industrial-600 hover:bg-industrial-500 text-white px-4 py-2 rounded-lg font-medium transition-colors"
          >
            New Invoice
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl text-sm">{error}</div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Overdue</p>
          <p className="text-2xl font-bold text-red-600">${summary.overdue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Due within 30 days</p>
          <p className="text-2xl font-bold text-gray-900">${summary.due30.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Drafts</p>
          <p className="text-2xl font-bold text-gray-500">${summary.drafts.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Paid (MTD)</p>
          <p className="text-2xl font-bold text-green-600">${summary.paid.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search invoices by # or customer…"
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-industrial-500"
            />
          </div>
          <button
            onClick={() => load()}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            title="Refresh"
          >
            <Filter size={20} />
            <span>Refresh</span>
          </button>
        </div>

        <table className="w-full text-left text-sm text-gray-600">
          <thead className="bg-gray-50 text-gray-900 font-semibold border-b border-gray-200">
            <tr>
              <th className="px-6 py-4">Invoice #</th>
              <th className="px-6 py-4">Customer</th>
              <th className="px-6 py-4">Date Issued</th>
              <th className="px-6 py-4">Due Date</th>
              <th className="px-6 py-4 text-right">Amount</th>
              <th className="px-6 py-4 text-center">Status</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading && (
              <tr>
                <td colSpan={7} className="px-6 py-10 text-center text-gray-500">
                  <div className="inline-flex items-center gap-2"><Loader className="animate-spin" size={18} /> Loading invoices…</div>
                </td>
              </tr>
            )}
            {!loading && items.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-10 text-center text-gray-500">No invoices found.</td>
              </tr>
            )}
            {!loading && items.map((inv) => {
              const status = String(inv.status || 'draft');
              const badgeClass =
                status.toLowerCase() === 'paid'
                  ? 'bg-green-100 text-green-700'
                  : status.toLowerCase() === 'overdue'
                    ? 'bg-red-100 text-red-700'
                    : status.toLowerCase() === 'sent'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-600';
              return (
                <tr key={inv.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{inv.id}</td>
                  <td className="px-6 py-4">{inv.customer_name || '—'}</td>
                  <td className="px-6 py-4">{inv.created_at ? new Date(inv.created_at).toLocaleDateString() : '—'}</td>
                  <td className="px-6 py-4 text-gray-500">{inv.due_date ? new Date(inv.due_date).toLocaleDateString() : '—'}</td>
                  <td className="px-6 py-4 text-right font-mono font-medium text-gray-900">
                    ${Number(inv.amount_due || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${badgeClass}`}>{status}</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button
                      className="text-industrial-600 hover:text-industrial-800 font-medium text-xs flex items-center justify-center gap-1 mx-auto"
                      onClick={() => alert('Invoice detail view coming next.')}
                    >
                      View <ArrowUpRight size={14} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default InvoiceList;
