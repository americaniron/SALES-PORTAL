import React, { useEffect, useState } from 'react';
import { Facebook, Loader, RefreshCw, ShieldAlert, CheckCircle2, AlertCircle } from 'lucide-react';

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.error || 'Request failed');
  return data as T;
}

export default function FacebookIntegration() {
  const [stats, setStats] = useState<{ leads: number; comments: number; messages: number } | null>(null);
  const [pages, setPages] = useState<Array<{ id: string; page_id: string; page_name: string; created_at: string }>>([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ type: 'ok' | 'err'; msg: string } | null>(null);

  const [pageId, setPageId] = useState('');
  const [pageName, setPageName] = useState('');
  const [accessToken, setAccessToken] = useState('');

  const load = async () => {
    setNotice(null);
    try {
      const d = await apiFetch<{ stats: { leads: number; comments: number; messages: number } }>('/api/facebook/stats');
      setStats(d.stats);
      const p = await apiFetch<{ items: any[] }>('/api/facebook/pages');
      setPages(p.items || []);
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Failed to load Facebook stats' });
    }
  };

  useEffect(() => { load(); }, []);

  const sync = async (kind: 'leads' | 'comments' | 'messages') => {
    setBusy(true);
    setNotice(null);
    try {
      const r = await apiFetch<{ ok: boolean; imported: number }>(`/api/facebook/sync/${kind}`, { method: 'POST' });
      setNotice({ type: 'ok', msg: `Synced ${kind}: imported ${r.imported}` });
      await load();
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Sync failed' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Facebook className="text-industrial-500" /> Facebook Integration
          </h1>
          <p className="text-gray-500">
            Capture followers/leads from comments, messages, and Facebook Lead Ads (Graph API). Some permissions require Meta App Review.
          </p>
        </div>
        <button
          onClick={load}
          disabled={busy}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
        >
          {busy ? <Loader className="animate-spin" size={18} /> : <RefreshCw size={18} />}
          Refresh
        </button>
      </div>

      {notice && (
        <div className={`p-4 rounded-xl border text-sm flex items-center gap-2 ${
          notice.type === 'ok' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          {notice.type === 'ok' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          {notice.msg}
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-4">
        <div className="flex items-start gap-2 text-sm text-gray-700">
          <ShieldAlert className="text-yellow-600" size={18} />
          <div>
            <div className="font-semibold">Required setup</div>
            <ol className="list-decimal ml-5 mt-1 space-y-1">
              <li>Create a Meta App (Business) and connect your Facebook Page.</li>
              <li>Generate a long-lived <b>Page Access Token</b> with required permissions (typically: <code>pages_read_engagement</code>, and for lead ads <code>leads_retrieval</code>).</li>
              <li>Add your Page ID + token below (stored in the portal DB). No token is stored in the browser.</li>
              <li>Use “Sync” to pull Lead Ads + recent comments. Messages are best captured via webhooks (Messenger) using <code>/api/facebook/webhook</code>.</li>
            </ol>
          </div>
        </div>

        <div className="rounded-lg border bg-gray-50 p-4 space-y-3">
          <div className="font-semibold text-sm">Add / Update Page Token (Admin)</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input className="border rounded px-3 py-2" placeholder="Page ID" value={pageId} onChange={e => setPageId(e.target.value)} />
            <input className="border rounded px-3 py-2" placeholder="Page Name (optional)" value={pageName} onChange={e => setPageName(e.target.value)} />
            <input className="border rounded px-3 py-2" placeholder="Long-lived Page Access Token" value={accessToken} onChange={e => setAccessToken(e.target.value)} />
          </div>
          <button
            disabled={busy || !pageId.trim() || !accessToken.trim()}
            onClick={async () => {
              setBusy(true);
              setNotice(null);
              try {
                await apiFetch('/api/facebook/pages', {
                  method: 'POST',
                  body: JSON.stringify({ page_id: pageId.trim(), page_name: pageName.trim(), access_token: accessToken.trim() })
                });
                setAccessToken('');
                setNotice({ type: 'ok', msg: 'Page token saved.' });
                await load();
              } catch (e: any) {
                setNotice({ type: 'err', msg: e?.message || 'Failed to save page token' });
              } finally {
                setBusy(false);
              }
            }}
            className="w-full md:w-auto px-4 py-2 rounded bg-industrial-600 hover:bg-industrial-500 text-white disabled:opacity-50"
          >Save Page</button>

          {pages.length > 0 && (
            <div className="text-xs text-gray-600">
              <div className="font-semibold mb-1">Configured pages</div>
              <ul className="list-disc ml-5 space-y-1">
                {pages.slice(0, 10).map(p => (
                  <li key={p.id}><span className="font-mono">{p.page_id}</span> — {p.page_name || 'Unnamed'}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-lg border bg-gray-50">
            <div className="text-sm text-gray-500">Leads (Ads)</div>
            <div className="text-2xl font-bold text-gray-900">{stats?.leads ?? '—'}</div>
            <button
              onClick={() => sync('leads')}
              disabled={busy}
              className="mt-3 w-full px-3 py-2 rounded bg-industrial-600 hover:bg-industrial-500 text-white disabled:opacity-50"
            >Sync Leads</button>
          </div>

          <div className="p-4 rounded-lg border bg-gray-50">
            <div className="text-sm text-gray-500">Comments</div>
            <div className="text-2xl font-bold text-gray-900">{stats?.comments ?? '—'}</div>
            <button
              onClick={() => sync('comments')}
              disabled={busy}
              className="mt-3 w-full px-3 py-2 rounded bg-industrial-600 hover:bg-industrial-500 text-white disabled:opacity-50"
            >Sync Comments</button>
          </div>

          <div className="p-4 rounded-lg border bg-gray-50">
            <div className="text-sm text-gray-500">Messages</div>
            <div className="text-2xl font-bold text-gray-900">{stats?.messages ?? '—'}</div>
            <button
              onClick={() => sync('messages')}
              disabled={busy}
              className="mt-3 w-full px-3 py-2 rounded bg-industrial-600 hover:bg-industrial-500 text-white disabled:opacity-50"
            >Sync Messages</button>
          </div>
        </div>

        <div className="text-xs text-gray-600">
          Imported records are stored for marketing follow-ups. You can convert leads into Contacts in the Marketing page.
        </div>
      </div>
    </div>
  );
}
