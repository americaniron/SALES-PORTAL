import React, { useEffect, useMemo, useState } from 'react';
import { Facebook, Link2, RefreshCcw, ShieldAlert } from 'lucide-react';

type FbPage = {
  id: string;
  page_id: string;
  page_name?: string;
  created_at: string;
};

type FbEvent = {
  id: string;
  page_id: string;
  type: string;
  sender_name?: string;
  message?: string;
  created_at: string;
};

async function apiFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const token = localStorage.getItem('ai_portal_token');
  const res = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'Request failed');
  return data as T;
}

export default function FacebookManager() {
  const [pages, setPages] = useState<FbPage[]>([]);
  const [events, setEvents] = useState<FbEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [pageId, setPageId] = useState('');
  const [pageName, setPageName] = useState('');
  const [pageToken, setPageToken] = useState('');

  const webhookUrl = useMemo(() => `${location.origin}/api/facebook/webhook`, []);

  const refresh = async () => {
    setError('');
    setLoading(true);
    try {
      const p = await apiFetch<{ items: FbPage[] }>('/api/facebook/pages');
      const e = await apiFetch<{ items: FbEvent[] }>('/api/facebook/events');
      setPages(p.items || []);
      setEvents(e.items || []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const savePage = async () => {
    setError('');
    if (!pageId.trim() || !pageToken.trim()) {
      setError('Page ID and Page Access Token are required.');
      return;
    }
    setLoading(true);
    try {
      await apiFetch('/api/facebook/pages', {
        method: 'POST',
        body: JSON.stringify({ page_id: pageId.trim(), page_name: pageName.trim() || null, access_token: pageToken.trim() }),
      });
      setPageId('');
      setPageName('');
      setPageToken('');
      await refresh();
      alert('Saved. Now connect the webhook + Lead Ads subscriptions in Meta Developers.');
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Facebook Integration</h1>
          <p className="text-gray-600 mt-1">Capture Leads from Lead Ads and log engagement from comments/messages via Webhooks.</p>
        </div>
        <button
          onClick={refresh}
          disabled={loading}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-black disabled:opacity-50"
        >
          <RefreshCcw size={16} />
          <span>Refresh</span>
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4 flex items-start space-x-2">
          <ShieldAlert size={18} className="mt-0.5" />
          <div className="text-sm">{error}</div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow p-6">
        <div className="flex items-center space-x-2">
          <Facebook className="text-industrial-500" size={22} />
          <h2 className="text-lg font-semibold text-gray-900">Webhook Endpoint</h2>
        </div>
        <div className="mt-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="text-sm text-gray-700">
            Use this URL in Meta Developers → Webhooks (Page):
            <div className="mt-1 font-mono text-xs bg-gray-100 rounded p-2 break-all">{webhookUrl}</div>
          </div>
          <button
            className="inline-flex items-center space-x-2 px-4 py-2 bg-industrial-600 text-white rounded-lg hover:bg-industrial-500"
            onClick={() => navigator.clipboard.writeText(webhookUrl)}
          >
            <Link2 size={16} />
            <span>Copy URL</span>
          </button>
        </div>
        <p className="mt-3 text-xs text-gray-500">
          Webhook verification requires the environment variable <code>FB_WEBHOOK_VERIFY_TOKEN</code>.
          Lead Ads capture requires storing a Page Access Token below.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Connected Pages</h2>
          <div className="text-xs text-gray-500">Admin only can add/update tokens</div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <input
            value={pageId}
            onChange={(e) => setPageId(e.target.value)}
            placeholder="Page ID (required)"
            className="px-3 py-2 border rounded-lg"
          />
          <input
            value={pageName}
            onChange={(e) => setPageName(e.target.value)}
            placeholder="Page Name (optional)"
            className="px-3 py-2 border rounded-lg"
          />
          <input
            value={pageToken}
            onChange={(e) => setPageToken(e.target.value)}
            placeholder="Page Access Token (required)"
            className="px-3 py-2 border rounded-lg"
          />
        </div>
        <button
          onClick={savePage}
          disabled={loading}
          className="mt-3 px-4 py-2 bg-industrial-600 text-white rounded-lg hover:bg-industrial-500 disabled:opacity-50"
        >
          Save Page Token
        </button>

        <div className="mt-5 overflow-auto border rounded-xl">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 py-2">Page ID</th>
                <th className="text-left px-4 py-2">Page Name</th>
                <th className="text-left px-4 py-2">Added</th>
              </tr>
            </thead>
            <tbody>
              {pages.map((p) => (
                <tr key={p.id} className="border-t">
                  <td className="px-4 py-2 font-mono text-xs">{p.page_id}</td>
                  <td className="px-4 py-2">{p.page_name || '—'}</td>
                  <td className="px-4 py-2 text-gray-600">{new Date(p.created_at).toLocaleString()}</td>
                </tr>
              ))}
              {!pages.length && (
                <tr className="border-t">
                  <td colSpan={3} className="px-4 py-6 text-center text-gray-500">No pages connected yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900">Recent Facebook Events</h2>
        <p className="text-xs text-gray-500 mt-1">Shows raw engagement events received by the webhook. Lead Ads will also create Leads automatically.</p>
        <div className="mt-4 overflow-auto border rounded-xl">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 py-2">Time</th>
                <th className="text-left px-4 py-2">Page</th>
                <th className="text-left px-4 py-2">Type</th>
                <th className="text-left px-4 py-2">Sender</th>
                <th className="text-left px-4 py-2">Message</th>
              </tr>
            </thead>
            <tbody>
              {events.map((ev) => (
                <tr key={ev.id} className="border-t">
                  <td className="px-4 py-2 text-gray-600">{new Date(ev.created_at).toLocaleString()}</td>
                  <td className="px-4 py-2 font-mono text-xs">{ev.page_id}</td>
                  <td className="px-4 py-2">{ev.type}</td>
                  <td className="px-4 py-2">{ev.sender_name || '—'}</td>
                  <td className="px-4 py-2 max-w-[420px] truncate" title={ev.message || ''}>{ev.message || '—'}</td>
                </tr>
              ))}
              {!events.length && (
                <tr className="border-t">
                  <td colSpan={5} className="px-4 py-6 text-center text-gray-500">No events yet. Connect the webhook in Meta Developers.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
