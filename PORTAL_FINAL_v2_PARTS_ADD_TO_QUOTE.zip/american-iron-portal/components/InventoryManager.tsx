import React, { useRef, useState } from 'react';
import { Database, Upload, Loader, CheckCircle2, AlertCircle } from 'lucide-react';

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.error || 'Request failed');
  return data as T;
}

export default function InventoryManager() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [type, setType] = useState<'equipment' | 'parts'>('equipment');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ type: 'ok' | 'err'; msg: string } | null>(null);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);

  const importJson = async (file: File) => {
    setBusy(true); setNotice(null);
    setProgress(null);
    try {
      const text = await file.text();
      const items = JSON.parse(text);
      if (!Array.isArray(items)) throw new Error('Invalid JSON. Expected an array of records.');
      const r = await apiFetch<{ ok: boolean; upserted: number }>(`/api/inventory/${type}/import`, {
        method: 'POST',
        body: JSON.stringify({ items })
      });
      setNotice({ type: 'ok', msg: `Upserted ${r.upserted} ${type} records.` });
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Import failed' });
    } finally {
      setBusy(false);
    }
  };

  const importBundledOneSafeSource = async () => {
    setBusy(true); setNotice(null);
    setProgress({ done: 0, total: 0 });
    try {
      const res = await fetch('/data/parts_onesafesource_import.json', { cache: 'no-store' });
      if (!res.ok) throw new Error('Bundled dataset not found in /public/data');
      const all = await res.json().catch(() => []);
      if (!Array.isArray(all) || all.length === 0) throw new Error('Bundled dataset is empty');

      const chunkSize = 100; // keep requests small; server also chunks DB.batch internally
      setProgress({ done: 0, total: all.length });

      let upserted = 0;
      for (let i = 0; i < all.length; i += chunkSize) {
        const slice = all.slice(i, i + chunkSize);
        const r = await apiFetch<{ ok: boolean; upserted: number }>(`/api/inventory/${type}/import`, {
          method: 'POST',
          body: JSON.stringify({ items: slice })
        });
        upserted += Number(r.upserted || 0);
        setProgress({ done: Math.min(i + chunkSize, all.length), total: all.length });
      }
      setNotice({ type: 'ok', msg: `Upserted ${upserted} ${type} records (bundled OneSafeSource).` });
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Bundled import failed' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Database className="text-industrial-500" /> Inventory Import
        </h1>
        <p className="text-gray-500">Upload the JSON inventory exports (equipment_inventory.json or parts_inventory.json) to seed the portal database.</p>
      </div>

      {notice && (
        <div className={`p-4 rounded-xl border text-sm flex items-center gap-2 ${
          notice.type === 'ok' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          {notice.type === 'ok' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          {notice.msg}
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-sm text-gray-700">Import type:</label>
          <select value={type} onChange={e => setType(e.target.value as any)} className="border rounded-lg px-3 py-2">
            <option value="equipment">Equipment</option>
            <option value="parts">Parts</option>
          </select>
        </div>

        <button
          disabled={busy}
          onClick={() => inputRef.current?.click()}
          className="inline-flex items-center gap-2 px-4 py-2 bg-industrial-600 hover:bg-industrial-500 text-white rounded-lg font-medium disabled:opacity-50"
        >
          {busy ? <Loader className="animate-spin" size={18} /> : <Upload size={18} />}
          Upload JSON
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={e => {
            const f = e.target.files?.[0];
            if (f) importJson(f);
            e.target.value = '';
          }}
        />

        {type === 'parts' && (
          <div className="pt-2">
            <button
              disabled={busy}
              onClick={importBundledOneSafeSource}
              className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
              title="Imports the bundled OneSafeSource parts dataset included with this portal build"
            >
              {busy ? <Loader className="animate-spin" size={18} /> : <Upload size={18} />}
              Import bundled OneSafeSource parts
            </button>
            <div className="text-xs text-gray-500 mt-2">
              Uses <code>/public/data/parts_onesafesource_import.json</code>. Best for first-time setup.
            </div>
          </div>
        )}

        {progress && (
          <div className="text-xs text-gray-700">
            Import progress: <span className="font-medium">{progress.done.toLocaleString()}</span> / {progress.total.toLocaleString()}
          </div>
        )}

        <div className="text-xs text-gray-600">
          Tip: for very large imports, upload in chunks (e.g., split the JSON into 5,000 records per file).
        </div>
      </div>
    </div>
  );
}
