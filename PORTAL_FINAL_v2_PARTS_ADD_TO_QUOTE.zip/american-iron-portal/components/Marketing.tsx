import React, { useEffect, useRef, useState } from 'react';
import { Mail, Upload, Send, Loader, CheckCircle2, AlertCircle } from 'lucide-react';

type Contact = {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  tags: string;
  source: string;
  created_at: string;
};

type Campaign = {
  id: string;
  name: string;
  subject: string;
  body_html: string;
  tag_filter: string;
  status: string;
  created_at: string;
};

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.error || 'Request failed');
  return data as T;
}

function parseCsv(text: string) {
  // Very small CSV/TSV parser (good enough for email/name/company/phone/tags columns).
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const n = text[i + 1];
    if (c === '"' && n === '"') { field += '"'; i++; continue; }
    if (c === '"') { inQuotes = !inQuotes; continue; }
    if (!inQuotes && (c === '\n' || c === '\r')) {
      if (c === '\r' && n === '\n') i++;
      row.push(field.trim()); field = '';
      if (row.some(v => v.length)) rows.push(row);
      row = [];
      continue;
    }
    field += c;
  }
  if (field.length || row.length) { row.push(field.trim()); if (row.some(v => v.length)) rows.push(row); }
  if (rows.length < 2) return [] as any[];

  const header = rows[0].map(h => h.toLowerCase().trim());
  return rows.slice(1).map(r => {
    const obj: any = {};
    header.forEach((h, idx) => { obj[h] = r[idx] ?? ''; });
    return obj;
  });
}

export default function Marketing() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ type: 'ok' | 'err'; msg: string } | null>(null);

  const [subject, setSubject] = useState('American Iron — Follow-up');
  const [tagFilter, setTagFilter] = useState('equipment,parts');
  const [html, setHtml] = useState('<p>Thanks for contacting American Iron LLC. Reply with what you need and we will quote quickly.</p>');

  const importRef = useRef<HTMLInputElement>(null);

  const loadAll = async () => {
    setLoading(true);
    setNotice(null);
    try {
      const c = await apiFetch<{ items: Contact[] }>('/api/marketing/contacts');
      const k = await apiFetch<{ items: Campaign[] }>('/api/marketing/campaigns');
      setContacts(c.items || []);
      setCampaigns(k.items || []);
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Failed to load marketing data' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  const doImport = async (file: File) => {
    setBusy(true);
    setNotice(null);
    try {
      const text = await file.text();
      const rows = parseCsv(text);
      const items = rows.map(r => ({
        email: String(r.email || r['e-mail'] || r['email address'] || '').trim(),
        name: String(r.name || r['full name'] || '').trim(),
        company: String(r.company || r['company name'] || '').trim(),
        phone: String(r.phone || r['phone number'] || '').trim(),
        tags: String(r.tags || '').trim(),
        source: 'import'
      })).filter(r => r.email || r.phone);

      if (!items.length) throw new Error('No contacts found. Include at least email or phone columns.');

      await apiFetch('/api/marketing/contacts/bulk', {
        method: 'POST',
        body: JSON.stringify({ items })
      });
      setNotice({ type: 'ok', msg: `Imported ${items.length} contacts.` });
      await loadAll();
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Import failed' });
    } finally {
      setBusy(false);
    }
  };

  const saveCampaign = async () => {
    setBusy(true);
    setNotice(null);
    try {
      await apiFetch('/api/marketing/campaigns', {
        method: 'POST',
        body: JSON.stringify({
          name: `Campaign ${new Date().toLocaleDateString()}`,
          subject,
          body_html: html,
          tag_filter: tagFilter
        })
      });
      setNotice({ type: 'ok', msg: 'Campaign saved.' });
      await loadAll();
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Failed to save campaign' });
    } finally {
      setBusy(false);
    }
  };

  const sendCampaign = async (id: string) => {
    if (!confirm('Send this campaign now?')) return;
    setBusy(true);
    setNotice(null);
    try {
      const data = await apiFetch<{ attempted: number; sent: number }>(`/api/marketing/campaigns/${encodeURIComponent(id)}/send`, { method: 'POST' });
      setNotice({ type: 'ok', msg: `Campaign triggered. Attempted: ${data.attempted}, Sent: ${data.sent}.` });
      await loadAll();
    } catch (e: any) {
      setNotice({ type: 'err', msg: e?.message || 'Send failed' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Mail className="text-industrial-500" /> Marketing
          </h1>
          <p className="text-gray-500">Import contacts and send campaigns. Website forms can push contacts into this list via /api/marketing/subscribe.</p>
        </div>

        <button
          onClick={() => importRef.current?.click()}
          disabled={busy}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
        >
          {busy ? <Loader className="animate-spin" size={18} /> : <Upload size={18} />}
          Import CSV
        </button>
        <input
          ref={importRef}
          type="file"
          accept=".csv,.tsv,text/csv"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) doImport(f);
            e.target.value = '';
          }}
        />
      </div>

      {notice && (
        <div className={`p-4 rounded-xl border text-sm flex items-center gap-2 ${notice.type === 'ok' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
          {notice.type === 'ok' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          {notice.msg}
        </div>
      )}

      {loading ? (
        <div className="bg-white rounded-xl border border-gray-200 p-6 flex items-center gap-2 text-gray-600">
          <Loader className="animate-spin" size={18} /> Loading marketing data…
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-5 border-b border-gray-200 font-semibold text-gray-900">
              Contacts ({contacts.length})
            </div>
            <div className="max-h-[520px] overflow-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-600">
                  <tr>
                    <th className="text-left px-4 py-2">Name</th>
                    <th className="text-left px-4 py-2">Email</th>
                    <th className="text-left px-4 py-2">Tags</th>
                  </tr>
                </thead>
                <tbody>
                  {contacts.slice(0, 250).map(c => (
                    <tr key={c.id} className="border-t">
                      <td className="px-4 py-2">
                        <div className="font-medium text-gray-900">{c.name || '—'}</div>
                        <div className="text-gray-500">{c.company || '—'}</div>
                      </td>
                      <td className="px-4 py-2 text-gray-700">{c.email || '—'}</td>
                      <td className="px-4 py-2 text-gray-600">{c.tags || '—'}</td>
                    </tr>
                  ))}
                  {!contacts.length && (
                    <tr className="border-t"><td className="px-4 py-3 text-gray-500" colSpan={3}>No contacts yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-5 border-b border-gray-200 font-semibold text-gray-900">
              Create Campaign
            </div>
            <div className="p-5 space-y-3">
              <input className="w-full px-3 py-2 border rounded-lg" placeholder="Subject" value={subject} onChange={e => setSubject(e.target.value)} />
              <input className="w-full px-3 py-2 border rounded-lg" placeholder="Tag filter (comma-separated)" value={tagFilter} onChange={e => setTagFilter(e.target.value)} />
              <textarea className="w-full px-3 py-2 border rounded-lg min-h-[180px] font-mono text-xs" value={html} onChange={e => setHtml(e.target.value)} />

              <button
                onClick={saveCampaign}
                disabled={busy || !subject.trim()}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-industrial-600 hover:bg-industrial-500 text-white rounded-lg font-medium disabled:opacity-50"
              >
                {busy ? <Loader className="animate-spin" size={18} /> : <Send size={18} />}
                Save Campaign
              </button>

              <div className="text-xs text-gray-500 pt-2 border-t">
                Saved campaigns:
              </div>
              <div className="space-y-2">
                {campaigns.map(c => (
                  <div key={c.id} className="flex items-center justify-between border rounded-lg px-3 py-2">
                    <div>
                      <div className="font-medium text-gray-900">{c.subject}</div>
                      <div className="text-xs text-gray-500">Tags: {c.tag_filter || '—'} • Status: {c.status}</div>
                    </div>
                    <button
                      onClick={() => sendCampaign(c.id)}
                      disabled={busy || c.status === 'sent'}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded bg-industrial-600 hover:bg-industrial-500 text-white disabled:opacity-50"
                    >
                      <Send size={14} /> Send
                    </button>
                  </div>
                ))}
                {!campaigns.length && <div className="text-sm text-gray-500">No campaigns yet.</div>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
