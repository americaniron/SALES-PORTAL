import React, { useEffect, useMemo, useState } from 'react';
import { Sparkles, Check, X, RefreshCw, Brain, Loader } from 'lucide-react';
import { AIAction } from '../types';

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'Request failed');
  return data as T;
}

const AIPortal = () => {
  const [suggestions, setSuggestions] = useState<AIAction[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await apiFetch<{ items: AIAction[] }>('/api/ai/suggestions');
      setSuggestions(data.items || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load AI suggestions');
      setSuggestions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pending = useMemo(() => suggestions.filter(s => s.status === 'suggested'), [suggestions]);

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    setBusy(true);
    setError('');
    try {
      await apiFetch(`/api/ai/suggestions/${encodeURIComponent(id)}`, {
        method: 'POST',
        body: JSON.stringify({ action }),
      });
      await load();
    } catch (e: any) {
      setError(e?.message || 'Action failed');
    } finally {
      setBusy(false);
    }
  };

  const generateNewCampaign = async () => {
    setBusy(true);
    setError('');
    try {
      await apiFetch(`/api/ai/suggestions`, {
        method: 'POST',
        body: JSON.stringify({ prompt: 'Weekly campaign for American Iron parts & equipment customers' }),
      });
      await load();
    } catch (e: any) {
      setError(e?.message || 'Campaign generation failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Sparkles className="text-industrial-500" />
            AI Sales Assistant
          </h1>
          <p className="text-gray-500">Review, approve, or reject AI-generated actions. (Gemini is run server-side.)</p>
        </div>
        <button
          onClick={generateNewCampaign}
          disabled={busy}
          className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50"
        >
          {busy ? <RefreshCw className="animate-spin" size={18} /> : <Brain size={18} />}
          <span>Generate Weekly Campaign</span>
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl text-sm">{error}</div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {loading && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-gray-600 flex items-center gap-2">
            <Loader className="animate-spin" size={18} /> Loading suggestions…
          </div>
        )}

        {!loading && pending.map((item) => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-1 h-full bg-industrial-500"></div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wide
                  ${item.type === 'upsell' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}
                `}>
                  {item.type}
                </span>
                <span className="text-sm text-gray-400 font-mono">Confidence: {(item.confidence * 100).toFixed(0)}%</span>
              </div>

              <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.suggestion}</h3>

              <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 mb-6">
                <p className="text-sm text-gray-600 italic">“{item.generated_message}”</p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => handleAction(item.id, 'approve')}
                  disabled={busy}
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-industrial-600 hover:bg-industrial-500 text-white rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                  <Check size={18} />
                  <span>Approve</span>
                </button>
                <button
                  onClick={() => handleAction(item.id, 'reject')}
                  disabled={busy}
                  className="px-4 py-2 bg-white border border-gray-300 hover:bg-red-50 text-gray-700 hover:text-red-600 rounded-lg font-medium transition-colors disabled:opacity-50"
                  title="Reject"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!loading && pending.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
          <Check className="mx-auto text-green-500 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-900">All caught up!</h3>
          <p className="text-gray-500">No pending AI suggestions.</p>
        </div>
      )}
    </div>
  );
};

export default AIPortal;
