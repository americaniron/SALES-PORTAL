import React, { useEffect, useMemo, useState } from 'react';
import { Search, Package, Loader, Image as ImageIcon, RefreshCw, Plus, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { addToQuoteCart, getQuoteCartCount } from '../utils/quoteCart';

type PartRow = {
  part_no: string;
  title?: string | null;
  details?: string | null;
  category?: string | null;
  price_usd?: number | null;
  qty?: number | null;
  location?: string | null;
  image_path?: string | null;
};

function getToken() {
  return localStorage.getItem('ai_portal_token') || '';
}

async function apiFetch<T>(url: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers);
  headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(url, { ...init, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.error || 'Request failed');
  return data as T;
}

async function loadLocalDataset(): Promise<PartRow[]> {
  const res = await fetch('/data/parts_onesafesource.json', { cache: 'force-cache' });
  if (!res.ok) throw new Error('Failed to load local parts dataset');
  const data = await res.json().catch(() => []);
  return Array.isArray(data) ? (data as PartRow[]) : [];
}

export default function PartsCatalog() {
  const navigate = useNavigate();
  const [toast, setToast] = useState<string>('');
  const [cartCount, setCartCount] = useState<number>(() => {
    try { return getQuoteCartCount(); } catch { return 0; }
  });
  const goToQuotes = () => navigate('/quotes');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<PartRow[]>([]);
  const [error, setError] = useState<string>('');
  const [usingFallback, setUsingFallback] = useState(false);

  const [localDataset, setLocalDataset] = useState<PartRow[] | null>(null);

  const handleAddToQuote = (p: PartRow) => {
    const sku = String(p.part_no || '').trim();
    if (!sku) return;
    addToQuoteCart({
      sku,
      description: String(p.title || p.details || sku),
      unit_price: p.price_usd == null ? 0 : Number(p.price_usd),
      quantity: 1,
    });
    try { setCartCount(getQuoteCartCount()); } catch { /* ignore */ }
    setToast(`Added ${sku} to quote.`);
    window.setTimeout(() => setToast(''), 2500);
  };

  const loadFromApi = async () => {
    const q = query.trim();
    const cat = category.trim();
    const url = `/api/parts/search?q=${encodeURIComponent(q)}${cat ? `&category=${encodeURIComponent(cat)}` : ''}`;
    const data = await apiFetch<{ items: PartRow[] }>(url);
    setItems(data.items || []);
  };

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      setUsingFallback(false);
      await loadFromApi();
    } catch (e: any) {
      // Fallback: allow using the bundled JSON dataset (works even without D1/API running)
      try {
        setUsingFallback(true);
        const ds = localDataset || (await loadLocalDataset());
        if (!localDataset) setLocalDataset(ds);

        const q = query.trim().toLowerCase();
        const cat = category.trim().toLowerCase();
        const filtered = ds.filter((p) => {
          if (cat && String(p.category || '').toLowerCase() !== cat) return false;
          if (!q) return true;
          const hay = `${p.part_no} ${p.title || ''} ${p.details || ''} ${p.category || ''}`.toLowerCase();
          return hay.includes(q);
        });

        setItems(filtered.slice(0, 200));
      } catch (e2: any) {
        setError(e?.message || e2?.message || 'Failed to load parts');
        setItems([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(), 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, category]);

  const categories = useMemo(() => {
    const src = localDataset || items;
    const set = new Set<string>();
    for (const p of src) {
      const c = String(p.category || '').trim();
      if (c) set.add(c);
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [items, localDataset]);

  const countText = useMemo(() => {
    if (loading) return 'Loading…';
    return `${items.length} result${items.length === 1 ? '' : 's'}`;
  }, [loading, items.length]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Package className="text-industrial-500" /> Parts Catalog
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Search parts by part number, description, or recommendations. {usingFallback ? 'Using bundled dataset (offline mode).' : ''}
          </p>
        </div>

        <button
          type="button"
          onClick={() => load()}
          className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          title="Refresh"
        >
          <RefreshCw size={18} />
          Refresh
        </button>

        <button
          type="button"
          onClick={goToQuotes}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-industrial-600 text-white hover:bg-industrial-700"
          title="Open Quotes"
        >
          <FileText size={18} />
          Quotes{cartCount ? ` (${cartCount})` : ''}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl text-sm">{error}</div>
      )}

      {toast && (
        <div className="bg-green-50 border border-green-200 text-green-800 p-3 rounded-xl text-sm flex flex-wrap items-center justify-between gap-3">
          <div>{toast}</div>
          <button
            type="button"
            onClick={goToQuotes}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-600 text-white hover:bg-green-700"
          >
            <FileText size={16} />
            Open Quotes
          </button>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by part number, description, or recommendations…"
              className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-industrial-500"
            />
          </div>

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm min-w-[220px]"
            title="Category"
          >
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <div className="text-sm text-gray-500">{countText}</div>
        </div>

        <div className="overflow-auto">
          <table className="w-full text-left text-sm text-gray-700">
            <thead className="bg-gray-50 text-gray-900 font-semibold border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 w-20">Photo</th>
                <th className="px-4 py-3 w-40">Part No.</th>
                <th className="px-4 py-3">Description</th>
                <th className="px-4 py-3 w-64">Recommendations</th>
                <th className="px-4 py-3 w-48">Category</th>
                <th className="px-4 py-3 w-24 text-right">Qty</th>
                <th className="px-4 py-3 w-32 text-right">Unit Price</th>
                <th className="px-4 py-3 w-40 text-right">Add</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading && (
                <tr>
                  <td colSpan={8} className="px-6 py-10 text-center text-gray-500">
                    <div className="inline-flex items-center gap-2"><Loader className="animate-spin" size={18} /> Loading parts…</div>
                  </td>
                </tr>
              )}

              {!loading && items.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-10 text-center text-gray-500">No parts found.</td>
                </tr>
              )}

              {!loading && items.map((p) => (
                <tr key={p.part_no} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    {p.image_path ? (
                      <img
                        src={p.image_path}
                        alt={p.part_no}
                        className="w-14 h-14 object-contain rounded bg-white border"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded border bg-gray-50 flex items-center justify-center text-gray-400">
                        <ImageIcon size={18} />
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono text-sm text-gray-900">{p.part_no}</td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">{p.title || '—'}</div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    <div className="line-clamp-3">{p.details || '—'}</div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{p.category || '—'}</td>
                  <td className="px-4 py-3 text-right">{p.qty == null ? '—' : String(p.qty)}</td>
                  <td className="px-4 py-3 text-right font-medium text-gray-900">
                    {p.price_usd == null ? '—' : `$${Number(p.price_usd).toFixed(2)}`}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      type="button"
                      onClick={() => handleAddToQuote(p)}
                      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-industrial-600 text-white hover:bg-industrial-700 text-xs"
                      title="Add this part to the quote cart"
                    >
                      <Plus size={14} />
                      Add to Quote
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 text-xs text-gray-500 border-t border-gray-100">
          Tip: After you import the OneSafeSource parts JSON into the portal database (Inventory Import → Parts), searches will use the database API.
        </div>
      </div>
    </div>
  );
}