import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  ExternalLink,
  Users,
  CreditCard,
  MessageSquare,
  Settings as SettingsIcon,
  LogOut,
  Menu,
  X,
  Megaphone,
  Facebook as FacebookIcon,
  Database,
} from 'lucide-react';

import Dashboard from './components/Dashboard';
import QuoteBuilder from './components/QuoteBuilder';
import ExternalQuoter from './components/ExternalQuoter';
import CustomerList from './components/CustomerList';
import InvoiceList from './components/InvoiceList';
import Messages from './components/Messages';
import Login from './components/Login';
import SettingsPage from './components/Settings';
import AIPortal from './components/AIPortal';
import Marketing from './components/Marketing';
import FacebookManager from './components/FacebookManager';
import InventoryManager from './components/InventoryManager';
import PartsCatalog from './components/PartsCatalog';

import { AuthContext } from './contexts/AuthContext';
import { UserRole } from './types';

const PortalLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = React.useContext(AuthContext);
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = useMemo(() => {
    const base = [
      { path: '/', label: 'Dashboard', icon: LayoutDashboard, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
      { path: '/quotes', label: 'Quotes', icon: FileText, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
      { path: '/external-quoter', label: 'External Quoter', icon: ExternalLink, roles: [UserRole.ADMIN, UserRole.SALES] },
      { path: '/customers', label: 'Customers', icon: Users, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
      { path: '/invoices', label: 'Invoices', icon: CreditCard, roles: [UserRole.ADMIN, UserRole.ACCOUNTING] },
      { path: '/messages', label: 'Messages', icon: MessageSquare, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
      { path: '/marketing', label: 'Marketing', icon: Megaphone, roles: [UserRole.ADMIN, UserRole.SALES] },
      { path: '/facebook', label: 'Facebook', icon: FacebookIcon, roles: [UserRole.ADMIN, UserRole.SALES] },
      { path: '/parts', label: 'Parts Catalog', icon: Database, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
      { path: '/inventory-import', label: 'Inventory Import', icon: Database, roles: [UserRole.ADMIN] },
      { path: '/settings', label: 'Settings', icon: SettingsIcon, roles: [UserRole.ADMIN] },
      { path: '/ai', label: 'AI Assistant', icon: SettingsIcon, roles: [UserRole.ADMIN, UserRole.SALES, UserRole.ACCOUNTING] },
    ];
    return base.filter(i => (user?.role ? i.roles.includes(user.role) : false));
  }, [user?.role]);

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Mobile header */}
      <div className="lg:hidden sticky top-0 z-40 bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white"
          >
            <Menu size={18} />
          </button>
          <div className="text-white font-bold tracking-wide">American Iron Portal</div>
        </div>
        <button
          onClick={logout}
          className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white"
          title="Logout"
        >
          <LogOut size={18} />
        </button>
      </div>

      {/* Sidebar */}
      <div className={`fixed inset-0 z-50 lg:hidden ${sidebarOpen ? '' : 'pointer-events-none'}`}>
        <div
          className={`absolute inset-0 bg-black/60 transition-opacity ${sidebarOpen ? 'opacity-100' : 'opacity-0'}`}
          onClick={() => setSidebarOpen(false)}
        />
        <div
          className={`absolute left-0 top-0 h-full w-80 bg-gray-950 border-r border-gray-800 transform transition-transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
        >
          <div className="p-4 flex items-center justify-between border-b border-gray-800">
            <div className="text-white font-bold tracking-wide">American Iron Portal</div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white"
            >
              <X size={18} />
            </button>
          </div>
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const active = location.pathname === item.path;
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    active ? 'bg-industrial-600 text-white' : 'text-gray-200 hover:bg-gray-800'
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Desktop layout */}
      <div className="hidden lg:flex">
        <aside className="w-72 bg-gray-950 min-h-screen border-r border-gray-800">
          <div className="p-5 border-b border-gray-800">
            <div className="text-white font-bold tracking-wide text-lg">American Iron Portal</div>
            <div className="text-gray-400 text-sm mt-1">{user?.email || ''}</div>
          </div>
          <nav className="p-4 space-y-1">
            {navItems.map((item) => {
              const active = location.pathname === item.path;
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    active ? 'bg-industrial-600 text-white' : 'text-gray-200 hover:bg-gray-800'
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
          <div className="mt-auto p-4 border-t border-gray-800">
            <button
              onClick={logout}
              className="w-full flex items-center justify-center space-x-2 px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </aside>

        <main className="flex-1 p-6">
          {children}
        </main>
      </div>

      {/* Mobile content */}
      <div className="lg:hidden p-4">
        {children}
      </div>
    </div>
  );
};

const App = () => {
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const ac = new AbortController();
    const checkSession = async () => {
      try {
        const token = localStorage.getItem('ai_portal_token');
        if (!token) return;

        const res = await fetch('/api/auth/me', {
          headers: { 'Authorization': `Bearer ${token}` },
          signal: ac.signal,
        });

        if (!res.ok) throw new Error('Session expired');
        const data = await res.json().catch(() => ({}));
        if (data?.user) {
          setUser(data.user);
          localStorage.setItem('ai_portal_user', JSON.stringify(data.user));
        }
      } catch {
        localStorage.removeItem('ai_portal_token');
        localStorage.removeItem('ai_portal_user');
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    checkSession();
    return () => ac.abort();
  }, []);

  const login = useCallback((token: string, userData: any) => {
    localStorage.setItem('ai_portal_token', token);
    localStorage.setItem('ai_portal_user', JSON.stringify(userData));
    setUser(userData);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('ai_portal_token');
    localStorage.removeItem('ai_portal_user');
    setUser(null);
  }, []);

  if (isLoading) {
    return (
      <div className="flex flex-col h-screen items-center justify-center bg-gray-900 text-white space-y-4">
        <div className="w-12 h-12 border-4 border-industrial-500 border-t-transparent rounded-full animate-spin"></div>
        <div className="font-bold tracking-widest animate-pulse uppercase text-sm">Initializing Portal...</div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      <HashRouter>
        <Routes>
          <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
          <Route
            path="/*"
            element={
              user ? (
                <PortalLayout>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/quotes" element={<QuoteBuilder />} />
                    <Route path="/external-quoter" element={<ExternalQuoter />} />
                    <Route path="/customers" element={<CustomerList />} />
                    <Route path="/invoices" element={<InvoiceList />} />
                    <Route path="/messages" element={<Messages />} />
                    <Route path="/marketing" element={<Marketing />} />
                    <Route path="/facebook" element={<FacebookManager />} />
                    <Route path="/parts" element={<PartsCatalog />} />
                    <Route path="/inventory-import" element={<InventoryManager />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="/ai" element={<AIPortal />} />
                    <Route path="*" element={<div className="p-8 bg-white rounded-lg shadow">Page under construction</div>} />
                  </Routes>
                </PortalLayout>
              ) : (
                <Navigate to="/login" replace />
              )
            }
          />
        </Routes>
      </HashRouter>
    </AuthContext.Provider>
  );
};

export default App;
