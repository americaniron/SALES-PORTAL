export interface Env {
  DB: any;
  GOOGLE_OAUTH_CLIENT_ID?: string;
  GOOGLE_OAUTH_CLIENT_SECRET?: string;
  GOOGLE_OAUTH_REFRESH_TOKEN?: string;
  EMAIL_FROM?: string;
  EMAIL_FROM_NAME?: string;
}

function base64UrlEncode(data: string) {
  return btoa(data).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function gmailAccessToken(env: Env): Promise<string> {
  if (!env.GOOGLE_OAUTH_CLIENT_ID || !env.GOOGLE_OAUTH_CLIENT_SECRET || !env.GOOGLE_OAUTH_REFRESH_TOKEN) {
    throw new Error('GMAIL_OAUTH_NOT_CONFIGURED');
  }

  const form = new URLSearchParams();
  form.set('client_id', env.GOOGLE_OAUTH_CLIENT_ID);
  form.set('client_secret', env.GOOGLE_OAUTH_CLIENT_SECRET);
  form.set('refresh_token', env.GOOGLE_OAUTH_REFRESH_TOKEN);
  form.set('grant_type', 'refresh_token');

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data?.access_token) {
    throw new Error(`GMAIL_OAUTH_TOKEN_ERROR: ${data?.error || res.status}`);
  }
  return String(data.access_token);
}

function buildMimeEmail(opts: {
  fromEmail: string;
  fromName?: string;
  toEmail: string;
  toName?: string;
  subject: string;
  html: string;
  replyTo?: string;
}) {
  const from = opts.fromName ? `${opts.fromName} <${opts.fromEmail}>` : opts.fromEmail;
  const to = opts.toName ? `${opts.toName} <${opts.toEmail}>` : opts.toEmail;

  const headers = [
    `From: ${from}`,
    `To: ${to}`,
    opts.replyTo ? `Reply-To: ${opts.replyTo}` : '',
    `Subject: ${opts.subject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset="UTF-8"',
  ].filter(Boolean).join('\r\n');

  return headers + '\r\n\r\n' + opts.html;
}

async function gmailSend(env: Env, mime: string) {
  const accessToken = await gmailAccessToken(env);
  const raw = base64UrlEncode(mime);

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`GMAIL_SEND_ERROR: ${data?.error?.message || res.status}`);
  }
  return data;
}

function nowIso() {
  return new Date().toISOString();
}

export default {
  // Run every 10–15 minutes (configure Cron Trigger in Cloudflare)
  async scheduled(_event: ScheduledEvent, env: Env, ctx: ExecutionContext) {
    ctx.waitUntil((async () => {
      const now = nowIso();
      const fromEmail = env.EMAIL_FROM || 'info@americaniron1.com';
      const fromName = env.EMAIL_FROM_NAME || 'American Iron LLC';

      const rows = await env.DB.prepare(
        `SELECT id, lead_id, to_email, subject, html
         FROM marketing_queue
         WHERE status = 'queued' AND send_at <= ?1
         ORDER BY send_at ASC
         LIMIT 50`
      ).bind(now).all<any>();

      const items = rows.results || [];
      for (const q of items) {
        try {
          const mime = buildMimeEmail({
            fromEmail,
            fromName,
            toEmail: String(q.to_email),
            subject: String(q.subject),
            html: String(q.html),
            replyTo: fromEmail,
          });

          await gmailSend(env, mime);

          await env.DB.prepare(
            `UPDATE marketing_queue SET status='sent', error=NULL WHERE id=?1`
          ).bind(String(q.id)).run();

        } catch (e: any) {
          await env.DB.prepare(
            `UPDATE marketing_queue SET status='error', error=?2 WHERE id=?1`
          ).bind(String(q.id), String(e?.message || e)).run();
        }
      }
    })());
  },
};
