# American Iron Portal

A production-ready Sales & Customer Portal built for the edge.

## Tech Stack
- **Frontend:** React + TypeScript + Tailwind (Vite)
- **Backend:** Cloudflare Pages Functions
- **Database:** Cloudflare D1 (SQLite)
- **AI:** Google Gemini (Server-side)
- **Storage:** Optional (R2) – not required for MVP

## Project Structure
- `/components`: React UI components
- `/functions`: Backend API routes (Cloudflare Workers runtime)
- `/db`: D1 schema (`db/d1_schema.sql`)

## Getting Started

### 1. Installation
```bash
npm install
```

### 2. Local Development
```bash
# Start Vite frontend
npm run dev
```

For local API development with Pages Functions, use Cloudflare's Pages dev tooling (optional):
```bash
# Build once
npm run build

# Serve dist + functions
npx wrangler pages dev ./dist
```

### 3. Database Setup (Cloudflare D1)
1. Create a D1 database in Cloudflare (Dashboard → D1)
2. Update `wrangler.toml` with your D1 `database_id`
3. Apply schema:
```bash
npx wrangler d1 execute american_iron_portal --file=./db/d1_schema.sql
```

## Parts Database (OneSafeSource)

This portal build includes a bundled parts dataset (part number, description, recommendations, qty, unit price) plus a set of mapped part photos.

- Dataset JSON files: `public/data/parts_onesafesource*.json`
- Photos: `public/parts_photos/`

### Import into D1

1. Deploy locally or to Cloudflare Pages with a D1 binding.
2. Log in as an admin.
3. Go to **Inventory Import → Parts → Import bundled OneSafeSource parts**.

After import:
- **Parts Catalog** will search via the database API.
- **Quotes** line items can use the 🔍 lookup button to auto-fill description and price from the parts database.

## Deployment (Cloudflare Pages)

1. **Connect Repo:** Link this GitHub repo to Cloudflare Pages.
2. **Build Settings:**
   - Framework: `Vite`
   - Command: `npm run build`
   - Output directory: `dist`
3. **Environment Variables (Settings -> Environment):**
   - `JWT_SECRET`: Long random secret for signing auth tokens.
   - `GEMINI_API_KEY`: Your Google AI Studio key (optional, enables AI parsing/suggestions).
   - `INVENTORY_API_BASE_URL`: Your website inventory API base URL (optional).
   - `INVENTORY_API_KEY`: Your API key for inventory sync (optional).
   - `STRIPE_SECRET_KEY`: For payment processing.
   - `TWILIO_ACCOUNT_SID`: For SMS.
4. **Functions:** Cloudflare automatically deploys the `/functions` directory as routing.

## Phasing Plan

### Phase 1: MVP (2 Weeks)
*Goal: Digitalize the quoting process and replace manual PDF creation.*

**Scope:**
- **Auth:** Admin/Sales/Customer roles.
- **CRM:** Basic Customer/Contact management.
- **Quoting:** Create, Edit, PDF View (Print), Send (Email trigger).
- **Invoicing:** Convert Quote to Invoice, Stripe Payment Link.
- **AI:** Basic "Next Action" suggestion based on mock history.

**Day-by-Day:**
- **Days 1-3:** Repo setup, DB Schema, Auth (Cookies).
- **Days 4-7:** Quote Builder UI, PDF Print CSS, Email integration.
- **Days 8-10:** Customer Portal (View Quote, Accept button).
- **Days 11-14:** Testing, Stripe Webhook, Deploy.

### Phase 2: Enhancements
- **Logistics:** Shipping calculator integration.
- **Advanced AI:** Weekly automated campaign generation + approval workflow.
- **WhatsApp:** Twilio integration for instant messaging.
- **QuickBooks:** CSV export or API integration.
- **Mobile App:** PWA improvements.

## Testing
Run critical flow tests:
```bash
npm test
```
Tests cover: Quote calculations, Auth guards, API response formats.
